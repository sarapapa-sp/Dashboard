"""Global Markets Dash app with an extendable left-hand page navigator.

Start from the project root: python app.py
"""
import logging
import os

import dash
from dash import Dash, Input, Output, dcc, html

from core.user_service import get_current_user

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')

app = Dash(
    __name__, use_pages=True, pages_folder='pages',
    suppress_callback_exceptions=True,
    title='Global Markets | PNL Reporting',
)
server = app.server


def navigation_links(pathname: str | None):
    """Generate active links from Dash's page registry; no hard-coded pages."""
    pathname = (pathname or '/').rstrip('/') or '/'
    pages = sorted(dash.page_registry.values(), key=lambda page: page.get('order', 99))
    return [
        dcc.Link([
            html.Span(f'{number:02d}', className='nav-number'),
            html.Span(page['name'], className='nav-text'),
        ], href=page['relative_path'],
           className=('sidebar-link active' if pathname == (page['relative_path'].rstrip('/') or '/')
                      else 'sidebar-link'),
           title=page['name'])
        for number, page in enumerate(pages, start=1)
    ]


def serve_layout():
    user_id, username = get_current_user()
    return html.Div([
        dcc.Location(id='page-url', refresh=False),
        html.Aside([
            html.Div([
                html.Div('GM', className='brand-mark'),
                html.Div([
                    html.Div('GLOBAL MARKETS', className='eyebrow sidebar-eyebrow'),
                    html.Div('PNL Reporting', className='brand-title'),
                ], className='brand-copy'),
            ], className='brand'),
            html.Div('WORKSPACE', className='sidebar-heading'),
            html.Nav(id='sidebar-navigation',
                     children=navigation_links('/'),
                     className='navigation',
                     **{'aria-label': 'Dashboard pages'}),
            html.Div([
                html.Span('REPORTING PLATFORM', className='sidebar-foot-title'),
                html.Span('Global Markets Analytics', className='sidebar-foot-subtitle'),
            ], className='sidebar-footer'),
        ], className='sidebar'),
        html.Div([
            html.Header([
                html.Div('Global Markets / Analytics', className='topbar-context'),
                html.Span('REPORTING PLATFORM', className='header-note'),
            ], className='topbar'),
            dash.page_container,
            html.Footer([
                html.Span('Signed in as', className='user-footer-caption'),
                html.Strong(username, className='user-footer-name'),
                html.Span(f'User ID: {user_id}', className='user-footer-id'),
            ], className='user-footer'),
        ], className='main-area'),
    ], className='app-shell')


app.layout = serve_layout


@app.callback(Output('sidebar-navigation', 'children'), Input('page-url', 'pathname'))
def update_navigation(pathname):
    return navigation_links(pathname)


if __name__ == '__main__':
    app.run(host=os.environ.get('DASH_HOST', '127.0.0.1'),
            port=int(os.environ.get('DASH_PORT', '8050')),
            debug=os.environ.get('DASH_DEBUG', '0') == '1')
