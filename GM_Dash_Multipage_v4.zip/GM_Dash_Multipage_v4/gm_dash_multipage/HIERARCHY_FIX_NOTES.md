# Hierarchy-only referential fields and default Daily / MTD / YTD values

This is an **incremental patch** for the prior `GM_Dash_v4_Column_Selection_Patch.zip` applied to GM Dash Multipage v4. It does not contain the full application.

## Files to replace

1. `report_config.py` – PNL defaults: `daily`, `mtd`, `ytd`; optional `ytdn1`. The Version Comparison page defaults: `daily_v0`, `mtd_v0`, `ytd_v0`; the V1/V3 measures remain available but unchecked.
2. `core/grid_config.py` – referential fields are hidden as independent columns and stay represented only by Business Hierarchy. AG Grid's `pivotMode=True` changes **Columns-tool-panel checkbox** meaning to Row Group or Value selection; **no pivot columns** are permitted (`enablePivot=False` for all fields). The pivot UI and Column Labels drop zone remain hidden.
3. `core/report_page.py` – removes the prior `columnVisible`/`rowGroup`/`aggFunc` JavaScript synchronization listeners, which were forcing hierarchy columns visible.

The four modified `tests/` files are included for regression verification and can be copied over as well. `assets/dashAgGridFunctions.js` does not need changes; its old checkbox-sync functions are no longer called. The accounting formatter remains in use.

## Expected behavior

- Initial grid data is blank until first **REFRESH data**.
- Default hierarchy: COB Date > GBL > Sub-Business Line > Activity L1, displayed within **Business Hierarchy** only.
- Columns tool-panel checkboxes for these four referential dimensions are selected, though the fields are NOT displayed separately as ordinary columns.
- Active initial value columns are Daily, MTD, YTD (PNL); or Daily_V0, MTD_V0, YTD_V0 (comparison).
- Optional referential/value checkboxes can be selected in the Columns panel. Row Groups and Values selection changes client-side immediately, but **only REFRESH** loads or aggregates backend data for those columns.
- Clicking REFRESH never overwrites `columnDefs`, `columnState` or the dropdown values.
- The pivot mode flag is used **only** for AG Grid's native tool-panel selection semantics. There is no pivoting by column labels. In this mode, AG Grid intentionally displays grouped aggregates without exposing underlying leaf-level detail rows (the XLSX download still exports filtered underlying records).

## How to apply and test

Extract the patch ZIP over the parent folder containing `gm_dash_multipage`.

```bash
cd gm_dash_multipage
python -m pytest -q
python app.py
```

In the browser, check that the Columns panel has four selected referential fields and three selected values, while only the **Business Hierarchy** and three value columns appear in the grid. Select Activity L5 or YTD N-1 and click REFRESH to verify the additional field is loaded. Re-check that filters, row groups, and values are retained after refreshing.

Automated tests validate configuration, callbacks and aggregation; a live Dash AG Grid Enterprise browser check is still required to verify rendering in the exact installed version.
