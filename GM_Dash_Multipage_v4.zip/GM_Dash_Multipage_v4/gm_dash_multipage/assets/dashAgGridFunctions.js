// Keeps numeric formatting identical across ordinary values and pivot result values.
var dagfuncs = window.dashAgGridFunctions = window.dashAgGridFunctions || {};

dagfuncs.accountingFormatter = function(params) {
    const raw = params && params.value;
    if (raw === undefined || raw === null || raw === '') { return ''; }
    const value = Number(raw);
    if (!Number.isFinite(value)) { return String(raw); }
    if (Math.abs(value) < 0.5) { return '–'; }
    const digits = Math.round(Math.abs(value)).toLocaleString('en-US');
    return value < 0 ? '(' + digits + ')' : digits;
};
