"""Data, aggregation and export unit tests (no browser required)."""
from io import BytesIO
from zipfile import ZipFile

import pandas as pd

from core.data_service import (aggregate_for_grid, apply_filters, filter_options,
                               get_page_data, normalize_data)
from core.excel_export import to_excel_bytes
from core.grid_config import build_columns, grid_options
from report_config import FILTERS, FILTER_LABELS, PNL, VERSIONS


def test_both_sources_load():
    pnl, a = get_page_data(PNL)
    ver, b = get_page_data(VERSIONS)
    assert len(pnl) == 108 and len(ver) == 108
    assert 'daily' in pnl.columns and 'daily_v0' in ver.columns
    assert 'daily_v3' in ver.columns and 'ytd_v3' in ver.columns
    assert a > 0 and b > 0


def test_eight_filters_are_configured_two_rows_of_four():
    assert len(FILTERS) == 8
    assert FILTERS[:4] == ('cobdate', 'gbl', 'subbusinessline', 'activityl1')
    assert FILTERS[4:] == ('activityl5', 'ptf', 'indicator', 'source')
    assert all(x in FILTER_LABELS for x in FILTERS)


def test_multi_select_filters_and_latest_date():
    df, _ = get_page_data(VERSIONS)
    dates = filter_options(df, 'cobdate', descending=True)
    assert dates[0]['value'] == '2026-11-19'
    part = apply_filters(
        df, dates=['2026-11-19'], gbl=['Equities'],
        subbusinessline=['Cash Equities'], activityl1=['Trading'],
        activityl5=['Spot'], portfolio=['EQ-ALPHA-01', 'EQ-ALPHA-02'],
        indicator=['Delta'], source=['FO'],
    )
    assert len(part) == 2
    assert set(part['ptf']) == {'EQ-ALPHA-01', 'EQ-ALPHA-02'}
    assert (part['cobdate'] == '2026-11-19').all()
    assert (part['gbl'] == 'Equities').all()

    # Empty lists mean "All" and should not silently remove any records.
    assert len(apply_filters(df, dates=[], gbl=[], portfolio=[])) == len(df)
    assert len(apply_filters(df, gbl='Equities')) == len(apply_filters(df, gbl=['Equities']))
    assert len(apply_filters(df, gbl=['Equities', 'FX'])) > len(apply_filters(df, gbl=['Equities']))
    assert len(apply_filters(df, portfolio=['Not a real portfolio'])) == 0


def test_groupby_reduces_rows_preserving_pnl_and_all_grain_fields():
    original, _ = get_page_data(VERSIONS)
    subset = apply_filters(original, dates=['2026-11-19'], gbl=['Equities'])
    duplicate = pd.concat([subset, subset], ignore_index=True)
    aggregated = aggregate_for_grid(duplicate, VERSIONS)
    assert len(aggregated) == len(subset) < len(duplicate)
    assert set(VERSIONS.value_fields).issubset(aggregated)
    assert set(['cobdate', *VERSIONS.dimensions, 'indicator', 'source']).issubset(aggregated)
    for field in VERSIONS.value_fields:
        assert aggregated[field].sum() == duplicate[field].sum()

    # Do not merge rows for different indicators, sources, or COBs.
    second = subset.iloc[[0]].copy()
    second['indicator'] = 'New Indicator'
    third = subset.iloc[[0]].copy()
    third['source'] = 'New Source'
    fourth = subset.iloc[[0]].copy()
    fourth['cobdate'] = '2026-11-18'
    enriched = pd.concat([subset, second, third, fourth], ignore_index=True)
    assert len(aggregate_for_grid(enriched, VERSIONS)) == len(subset) + 3


def test_empty_aggregation():
    original, _ = get_page_data(PNL)
    blank = apply_filters(original, gbl=['Not a business'])
    grouped = aggregate_for_grid(blank, PNL)
    assert grouped.empty
    assert set(PNL.value_fields).issubset(grouped)


def test_schema_case_insensitive_and_aliases():
    df = pd.DataFrame([{
        'COB_Date': '2026-11-19', 'GBL': 'FX', 'SubBusinessLine': 'G10',
        'ActivityL1': 'Trading', 'Activity_L5': 'FX Spot', 'Portfolio': 'P1',
        'Daily_V0': 1, 'MTD_V0': 2, 'YTD_V0': 3,
        'Daily_V1': 4, 'MTD_V1': 5, 'YTD_V1': 6,
        'Daily_V3': 7, 'MTD_V3': 8, 'YTD_V3': 9,
    }])
    normalized = normalize_data(df, VERSIONS)
    assert normalized['daily_v3'].iloc[0] == 7
    assert normalized['ptf'].iloc[0] == 'P1'


def test_grid_value_columns_have_no_filters_and_no_group_counts():
    options = grid_options()
    assert options['autoGroupColumnDef']['cellRendererParams']['suppressCount'] is True
    value_defs = [c for group in build_columns(VERSIONS) for c in group['children'] if c['field'] in VERSIONS.value_fields]
    assert len(value_defs) == 9
    assert all(c['filter'] is False and c['floatingFilter'] is False for c in value_defs)
    assert options['pivotMode'] is True
    assert options['pivotPanelShow'] == 'never'


def test_excel_exports_source_not_grouped_rows():
    df, _ = get_page_data(VERSIONS)
    filtered = apply_filters(df, dates=['2026-11-19'], gbl=['FX'])
    duplicate = pd.concat([filtered, filtered], ignore_index=True)
    grouped = aggregate_for_grid(duplicate, VERSIONS)
    assert len(grouped) < len(duplicate)
    content = to_excel_bytes(duplicate, VERSIONS)
    assert content.startswith(b'PK')
    with ZipFile(BytesIO(content)) as archive:
        assert 'xl/worksheets/sheet1.xml' in archive.namelist()
        assert 'xl/workbook.xml' in archive.namelist()
    back = pd.read_excel(BytesIO(content), engine='openpyxl')
    assert len(back) == len(duplicate)
    assert 'Daily_V0' in back.columns and 'YTD_V3' in back.columns
    assert '_row_id' not in back.columns


def test_empty_excel():
    df, _ = get_page_data(PNL)
    content = to_excel_bytes(df.iloc[:0], PNL)
    back = pd.read_excel(BytesIO(content), engine='openpyxl')
    assert back.empty and 'Daily PNL' in back.columns
