"""Explicit v4 column-state/REFRESH specification tests."""
import pandas as pd
import pytest

from core.data_service import get_page_data, apply_filters, aggregate_for_grid
from core.grid_config import build_columns, grid_options
from report_config import DEFAULT_ROW_GROUPS, PNL, VERSIONS


def test_default_column_hierarchy_and_dependent_values_for_both_pages():
    for spec in (PNL, VERSIONS):
        defs = [col for group in build_columns(spec) for col in group['children']]
        active_groups = [d['field'] for d in defs if d.get('rowGroup')]
        inactive_groups = [d['field'] for d in defs
                           if d.get('enableRowGroup') and not d.get('rowGroup')]
        active_values = [d['field'] for d in defs if d.get('aggFunc') == 'sum']
        assert active_groups == list(DEFAULT_ROW_GROUPS)
        assert inactive_groups == ['activityl5', 'ptf', 'indicator', 'source']
        assert active_values == list(spec.default_value_fields)
        assert all(d['hide'] is True for d in defs if d.get('enableRowGroup'))
        assert all(d['enableValue'] for d in defs if d['field'] in spec.value_fields)
    opt = grid_options()
    assert opt['pivotMode'] is True and opt['pivotPanelShow'] == 'never'
    assert opt['rowGroupPanelShow'] == 'always'
    assert opt['groupDisplayType'] == 'singleColumn'


def test_backend_aggregation_reduces_selected_date_and_uses_selected_grain():
    df, _ = get_page_data(PNL)
    filtered = apply_filters(df, dates=['2026-11-19'])
    aggregated = aggregate_for_grid(filtered, PNL,
                                     group_fields=list(DEFAULT_ROW_GROUPS),
                                     value_fields=list(PNL.value_fields))
    assert len(filtered) == 36
    assert len(aggregated) == 6
    assert set(aggregated) == {*DEFAULT_ROW_GROUPS, *PNL.value_fields}
    for value in PNL.value_fields:
        assert aggregated[value].sum() == pytest.approx(filtered[value].sum())

    # A newly selected *secondary* dimension changes the aggregation grain.
    enriched = aggregate_for_grid(filtered, PNL,
                                  group_fields=[*DEFAULT_ROW_GROUPS, 'ptf'],
                                  value_fields=['daily'])
    assert len(enriched) > len(aggregated)
    assert set(enriched.columns) == {*DEFAULT_ROW_GROUPS, 'ptf', 'daily'}
    assert enriched['daily'].sum() == pytest.approx(filtered['daily'].sum())


def test_no_numeric_value_selected_and_invalid_group_prevention():
    df, _ = get_page_data(VERSIONS)
    filtered = apply_filters(df, dates=['2026-11-19'])
    grouped = aggregate_for_grid(filtered, VERSIONS,
                                 group_fields=['gbl'], value_fields=[])
    assert set(grouped) == {'cobdate', 'gbl'}
    assert len(grouped) == filtered['gbl'].nunique()
    with pytest.raises(ValueError, match='Unsupported grouping'):
        aggregate_for_grid(filtered, VERSIONS, group_fields=['not_a_column'])
    with pytest.raises(ValueError, match='Unsupported value'):
        aggregate_for_grid(filtered, VERSIONS, value_fields=['not_a_measure'])
