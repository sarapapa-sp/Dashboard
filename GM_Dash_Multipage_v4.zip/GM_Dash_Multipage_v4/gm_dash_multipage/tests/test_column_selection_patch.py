"""Focused regression tests for the Columns panel / hierarchy alignment patch."""
from dataclasses import replace
from pathlib import Path
from core.grid_config import build_columns, build_referential_columns, build_value_columns, grid_options
from report_config import (DEFAULT_REFERENTIAL_COLUMNS, PNL, REFERENTIAL_COLUMNS,
                           SECONDARY_REFERENTIAL_COLUMNS, VERSIONS)


def test_selected_and_secondary_referential_columns_are_distinct():
    assert DEFAULT_REFERENTIAL_COLUMNS == ('cobdate', 'gbl', 'subbusinessline', 'activityl1')
    assert SECONDARY_REFERENTIAL_COLUMNS == ('activityl5', 'ptf', 'indicator', 'source')
    assert REFERENTIAL_COLUMNS == (*DEFAULT_REFERENTIAL_COLUMNS, *SECONDARY_REFERENTIAL_COLUMNS)
    for spec in (PNL, VERSIONS):
        defs = build_referential_columns(spec)
        assert [c['field'] for c in defs] == list(REFERENTIAL_COLUMNS)
        assert [c['field'] for c in defs if c['rowGroup']] == list(DEFAULT_REFERENTIAL_COLUMNS)
        # All grouping keys are hidden as standalone grid columns. In native
        # pivot mode, the Columns checkbox uses rowGroup rather than hide.
        assert all(c['hide'] for c in defs)
        assert all(not c['enablePivot'] and not c['enableValue'] for c in defs)


def test_value_columns_separate_with_per_page_optional_defaults():
    assert [v['field'] for v in build_value_columns(PNL)] == list(PNL.value_fields)
    assert [v['field'] for v in build_value_columns(VERSIONS)] == list(VERSIONS.value_fields)
    custom = replace(VERSIONS, default_values=('daily_v0', 'mtd_v0'))
    values = build_value_columns(custom)
    assert [v['field'] for v in values if v['aggFunc'] == 'sum'] == ['daily_v0', 'mtd_v0']
    assert [v['field'] for v in values if v['hide']] == list(custom.value_fields[2:])
    assert custom.secondary_value_fields == custom.value_fields[2:]
    assert [g['headerName'] for g in build_columns(custom)] == ['Referential Columns', 'Value Columns']


def test_pivot_mode_only_changes_checkbox_semantics_not_pivot_columns():
    opts = grid_options()
    assert opts['pivotMode'] is True
    assert opts['groupDisplayType'] == 'singleColumn'
    assert opts['pivotPanelShow'] == 'never'
    panel = opts['sideBar']['toolPanels'][0]['toolPanelParams']
    assert panel['suppressPivots'] is True
    assert panel['suppressPivotMode'] is True
    assert opts['suppressDragLeaveHidesColumns'] is True
    assert opts['suppressMakeColumnVisibleAfterUnGroup'] is True
    assert all(not c['enablePivot'] for group in build_columns(VERSIONS)
               for c in group['children'])


def test_native_column_selection_has_no_browser_visibility_sync_handlers():
    """Former JS handlers would turn grouped hidden fields visible again."""
    page = (Path(__file__).resolve().parents[1] / 'core/report_page.py').read_text()
    assert 'eventListeners=' not in page
    assert 'syncColumnGroupSelection(params)' not in page
    assert 'syncColumnCheckbox(params)' not in page


def test_page_specific_initial_value_selection():
    assert PNL.default_value_fields == ('daily', 'mtd', 'ytd')
    assert PNL.secondary_value_fields == ('ytdn1',)
    assert VERSIONS.default_value_fields == ('daily_v0', 'mtd_v0', 'ytd_v0')
    assert VERSIONS.secondary_value_fields == (
        'daily_v1', 'mtd_v1', 'ytd_v1', 'daily_v3', 'mtd_v3', 'ytd_v3'
    )
    for spec in (PNL, VERSIONS):
        defs = build_value_columns(spec)
        assert [col['field'] for col in defs if col['aggFunc'] == 'sum'] == list(spec.default_value_fields)
        assert [col['field'] for col in defs if col['aggFunc'] is None] == list(spec.secondary_value_fields)
