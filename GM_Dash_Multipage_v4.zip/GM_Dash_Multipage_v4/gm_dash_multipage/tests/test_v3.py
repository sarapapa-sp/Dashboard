"""Stable cache, layout options, and refresh-only state regression tests (v4)."""
from dataclasses import replace
from io import BytesIO
import importlib
import sys
import types

import pandas as pd
import pytest

from core.data_service import get_page_data
from core.grid_config import build_columns, grid_options
from core.user_service import get_current_user
from report_config import DEFAULT_ROW_GROUPS, FILTERS, OPTIONAL_FILTERS, PNL, VERSIONS


def test_group_panel_without_pivot_label_zone_and_user_provider():
    options = grid_options()
    assert options['rowGroupPanelShow'] == 'always'
    assert options['pivotPanelShow'] == 'never'
    assert options['pivotMode'] is True
    assert options['rowHeight'] == 30
    userid, username = get_current_user()
    assert isinstance(userid, str) and isinstance(username, str)
    assert userid and username


def test_source_changes_are_staged_until_refresh(monkeypatch, tmp_path):
    example = pd.read_excel('data/sample_pnl.xlsx').iloc[:2].copy()
    path = tmp_path / 'data.csv'
    example.to_csv(path, index=False)
    spec = replace(PNL, key='v4-cache-only-on-refresh')
    monkeypatch.setenv('DASH_PNL_FILE', str(path))

    first, seq1 = get_page_data(spec)
    assert len(first) == 2
    pd.concat([example, example], ignore_index=True).to_csv(path, index=False)
    stale, seq2 = get_page_data(spec)
    assert seq1 == seq2 and len(stale) == 2
    refreshed, seq3 = get_page_data(spec, refresh=True)
    assert seq3 == seq1 + 1 and len(refreshed) == 4


def _column_state(spec):
    return [
        {'colId': col['field'], 'rowGroup': col.get('rowGroup', False),
         'rowGroupIndex': col.get('rowGroupIndex'), 'aggFunc': col.get('aggFunc')}
        for group in build_columns(spec) for col in group['children']
    ]


@pytest.fixture
def callback_harness(monkeypatch):
    """Execute Dash callbacks as Python functions with registered dependencies.

    This verifies the trigger/output contract and backend aggregation, but
    it is not a replacement for real-browser AG Grid Enterprise testing.
    """
    registered = []
    fake_dash = types.ModuleType('dash')
    fake_dag = types.ModuleType('dash_ag_grid')
    fake_exceptions = types.ModuleType('dash.exceptions')

    class PreventUpdate(Exception):
        pass

    class Dependency:
        def __init__(self, kind, component_id, property_name):
            self.kind = kind
            self.component_id = component_id
            self.property_name = property_name

    def dependency(kind):
        return lambda component_id, property_name: Dependency(kind, component_id, property_name)

    def callback(*dependencies, **kwargs):
        def decorator(func):
            registered.append((dependencies, kwargs, func))
            return func
        return decorator

    class DummyNode:
        def __init__(self, *children, **attrs):
            self.children, self.attrs = children, attrs

    node = lambda *args, **kwargs: DummyNode(*args, **kwargs)

    def send_bytes(writer, filename):
        buffer = BytesIO()
        writer(buffer)
        return {'filename': filename, 'content': buffer.getvalue()}

    fake_dash.Input = dependency('Input')
    fake_dash.Output = dependency('Output')
    fake_dash.State = dependency('State')
    fake_dash.callback = callback
    fake_dash.dcc = types.SimpleNamespace(send_bytes=send_bytes, Store=node, Dropdown=node, Input=node, Download=node, Loading=node)
    fake_dash.html = types.SimpleNamespace(Div=node, Span=node, Strong=node, Label=node, Button=node, Section=node, H2=node, P=node, H1=node)
    fake_dash.no_update = object()
    fake_exceptions.PreventUpdate = PreventUpdate
    fake_dag.AgGrid = node

    monkeypatch.setitem(sys.modules, 'dash', fake_dash)
    monkeypatch.setitem(sys.modules, 'dash.exceptions', fake_exceptions)
    monkeypatch.setitem(sys.modules, 'dash_ag_grid', fake_dag)
    sys.modules.pop('core.report_callbacks', None)
    sys.modules.pop('core.report_page', None)

    module = importlib.import_module('core.report_callbacks')
    module.register_report_callbacks(VERSIONS)
    assert len(registered) == 4
    yield registered, module, fake_dash, PreventUpdate
    sys.modules.pop('core.report_callbacks', None)
    sys.modules.pop('core.report_page', None)


def test_refresh_only_trigger_and_preserved_column_and_filter_props(callback_harness):
    registered, module, fake_dash, PreventUpdate = callback_harness
    initial_deps, _, initialize = registered[0]
    deps, kwargs, refresh = registered[1]

    initial_inputs = [dep for dep in initial_deps if dep.kind == 'Input']
    assert [(dep.component_id, dep.property_name) for dep in initial_inputs] == [('versions-filter-init', 'data')]
    init_output_fields = {(d.component_id, d.property_name) for d in initial_deps if d.kind == 'Output'}
    assert ('versions-date', 'value') in init_output_fields
    assert ('versions-grid', 'rowData') not in init_output_fields

    init_result = initialize({'page': 'versions'}, [])
    assert init_result[len(FILTERS)] == ['2026-11-19']  # default COB
    assert initialize({'page': 'versions'}, ['2026-11-18'])[len(FILTERS)] is fake_dash.no_update

    inputs = [dep for dep in deps if dep.kind == 'Input']
    assert len(inputs) == 1
    assert (inputs[0].component_id, inputs[0].property_name) == ('versions-refresh', 'n_clicks')
    states = [dep for dep in deps if dep.kind == 'State']
    assert len(states) == len(FILTERS) + 1
    assert states[-1].component_id == 'versions-grid'
    assert states[-1].property_name == 'columnState'
    outputs = {(dep.component_id, dep.property_name)
               for dep in deps if dep.kind == 'Output'}
    assert outputs == {
        ('versions-grid', 'rowData'), ('versions-grid-status', 'children'),
        ('versions-row-stats', 'children'), ('versions-applied-snapshot', 'data'),
    }
    assert kwargs.get('prevent_initial_call') is True
    with pytest.raises(PreventUpdate):
        refresh(0, *([[]] * len(FILTERS)), _column_state(VERSIONS))

    state = _column_state(VERSIONS)
    chosen = [['2026-11-18'], ['FX']] + [[] for _ in FILTERS[2:]]
    result = refresh(1, *chosen, state)
    rows, message, summary, snapshot = result
    assert rows and all(row['cobdate'] == '2026-11-18' for row in rows)
    assert all(row['gbl'] == 'FX' for row in rows)
    assert snapshot['filters']['gbl'] == ['FX']
    assert snapshot['filters']['dates'] == ['2026-11-18']  # no reset to latest
    assert snapshot['group_fields'] == list(DEFAULT_ROW_GROUPS)
    assert snapshot['value_fields'] == list(VERSIONS.default_value_fields)
    assert '4 grouping columns' in message
    assert summary.__class__.__name__ == 'DummyNode'

    # The saved filter selections control download, not later un-applied edits.
    download = registered[2][2]
    out, status = download(1, snapshot)
    back = pd.read_excel(BytesIO(out['content']))
    assert set(back['GBL']) == {'FX'}
    assert set(pd.to_datetime(back['COB Date']).dt.strftime('%Y-%m-%d')) == {'2026-11-18'}
    assert 'last applied filters' in status


def test_added_secondary_group_and_removed_values_apply_only_after_refresh(callback_harness):
    registered, module, _, _ = callback_harness
    refresh = registered[1][2]
    df, _ = get_page_data(VERSIONS)
    staged_filters = [['2026-11-19']] + [[] for _ in FILTERS[1:]]

    state = _column_state(VERSIONS)
    first_rows, _, _, first_snapshot = refresh(1, *staged_filters, state)
    assert first_rows
    first_columns = set(first_rows[0]) - {'_row_id'}
    assert first_columns == {*DEFAULT_ROW_GROUPS, *VERSIONS.default_value_fields}
    assert all('activityl5' not in row and 'ptf' not in row
               and 'indicator' not in row and 'source' not in row for row in first_rows)

    # User adds Activity L5 in the AG Grid Columns panel, without refreshing.
    # The already-delivered rowData still DOES NOT have this field.
    new_state = [dict(s) for s in state]
    for col in new_state:
        if col['colId'] == 'activityl5':
            col.update(rowGroup=True, rowGroupIndex=4)
        if col['colId'] not in ('daily_v0', 'mtd_v0') and col['colId'] in VERSIONS.value_fields:
            col['aggFunc'] = None
    assert 'activityl5' not in first_rows[0]

    # Clicking REFRESH reads updated columnState and delivers newly grouped data.
    second_rows, _, summary, second_snapshot = refresh(2, *staged_filters, new_state)
    assert second_snapshot['group_fields'] == [*DEFAULT_ROW_GROUPS, 'activityl5']
    assert second_snapshot['value_fields'] == ['daily_v0', 'mtd_v0']
    second_columns = set(second_rows[0]) - {'_row_id'}
    assert second_columns == {*DEFAULT_ROW_GROUPS, 'activityl5', 'daily_v0', 'mtd_v0'}
    assert 'ptf' not in second_columns and 'daily_v3' not in second_columns
    assert len(second_rows) >= len(first_rows)

    # Adding a previously unchecked V1 measure must be deferred until REFRESH.
    optional_value_state = [dict(s) for s in new_state]
    for item in optional_value_state:
        if item['colId'] == 'ytd_v1':
            item['aggFunc'] = 'sum'
    assert 'ytd_v1' not in second_rows[0]
    third_rows, _, _, third_snapshot = refresh(3, *staged_filters, optional_value_state)
    assert third_snapshot['value_fields'] == ['daily_v0', 'mtd_v0', 'ytd_v1']
    assert 'ytd_v1' in third_rows[0]

    full = df.loc[df['cobdate'].eq('2026-11-19')]
    assert sum(row['daily_v0'] for row in first_rows) == pytest.approx(full['daily_v0'].sum())
    assert sum(row['daily_v0'] for row in second_rows) == pytest.approx(full['daily_v0'].sum())


def test_failed_refresh_preserves_current_grid_and_applied_snapshot(callback_harness, monkeypatch):
    registered, module, fake_dash, _ = callback_harness
    refresh = registered[1][2]
    old = refresh(1, *([[]] * len(FILTERS)), _column_state(VERSIONS))
    assert old[3]

    def boom(*args, **kwargs):
        raise IOError('bad source')
    monkeypatch.setattr(module, 'get_page_data', boom)
    failed = refresh(2, *([[]] * len(FILTERS)), _column_state(VERSIONS))
    assert failed[0] is fake_dash.no_update
    assert failed[2] is fake_dash.no_update
    assert failed[3] is fake_dash.no_update
    assert 'Refresh failed' in failed[1]
