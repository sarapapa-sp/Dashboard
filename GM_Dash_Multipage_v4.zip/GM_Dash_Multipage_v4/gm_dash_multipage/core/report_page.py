"""Shared report page: staged eight-filter controls and an enterprise AG Grid."""
from __future__ import annotations

from dash import dcc, html
import dash_ag_grid as dag

from core.grid_config import DEFAULT_COLUMN_DEF, build_columns, grid_options
from report_config import FILTERS, FILTER_LABELS, OPTIONAL_FILTERS, ReportSpec


def cid(spec: ReportSpec, suffix: str) -> str:
    return f'{spec.key}-{suffix}'


def filter_id(spec: ReportSpec, field: str) -> str:
    # Preserve the historic -date suffix for COB Date.
    return cid(spec, 'date' if field == 'cobdate' else field)


def _filter_component(spec: ReportSpec, field: str) -> html.Div:
    label = FILTER_LABELS[field]
    placeholder = 'Select dates' if field == 'cobdate' else f'All {label}'
    return html.Div([
        html.Label(label, htmlFor=filter_id(spec, field)),
        dcc.Dropdown(
            id=filter_id(spec, field), options=[], value=[], multi=True,
            searchable=True, clearable=True,
            disabled=field in OPTIONAL_FILTERS,
            placeholder=placeholder,
            className='multi-filter-select',
            persistence=True, persistence_type='session',
        ),
    ], className='filter-control')


def layout(spec: ReportSpec) -> html.Div:
    id_ = lambda suffix: cid(spec, suffix)
    return html.Div([
        # Only the last successful button press writes this applied filter snapshot.
        # Do not put the full dataframe into a browser dcc.Store.
        dcc.Store(id=id_('applied-snapshot'), storage_type='memory'),
        dcc.Store(id=id_('filter-init'), data={'page': spec.key}, storage_type='memory'),
        html.Div([
            html.Div([
                html.Div('GLOBAL MARKETS  /  REPORTING', className='eyebrow page-eyebrow'),
                html.H1(spec.title, className='page-title'),
                html.P(spec.subtitle, className='page-subtitle'),
            ], className='page-title-block'),
            html.Div([
                html.Div([
                    html.Button('REFRESH data', id=id_('refresh'), n_clicks=0,
                                className='action-button secondary-button'),
                    html.Button('DOWNLOAD XLSX', id=id_('download-button'), n_clicks=0,
                                className='action-button primary-button'),
                    dcc.Download(id=id_('download')),
                ], className='heading-actions'),
                html.Div('Source rows: —   |   Matching rows: —   |   Aggregated rows: —',
                         id=id_('row-stats'), className='row-summary-box',
                         role='status', **{'aria-live': 'polite'}),
            ], className='header-controls'),
        ], className='page-heading'),

        html.Section([
            html.Div([
                html.Div([
                    html.H2('Data filters', className='section-title'),
                    html.P('Choose multiple values; empty means All. Changes take effect only after REFRESH data.',
                           className='section-subtitle'),
                ]),
                html.Span('8 MULTI-SELECT FILTERS', className='filters-count'),
            ], className='filters-heading'),
            html.Div([_filter_component(spec, field) for field in FILTERS],
                     className='filters-grid'),
        ], className='filters-panel'),

        html.Section([
            html.Label('Request / command', className='request-label'),
            html.Div([
                dcc.Input(id=id_('request'), className='request-input',
                          type='text', debounce=False, placeholder='Enter a request...'),
                html.Button('Send', id=id_('send-request'), n_clicks=0,
                            className='action-button send-button'),
            ], className='request-row'),
            html.Div(id=id_('request-response'), className='request-response', role='status'),
        ], className='request-panel'),

        html.Section([
            html.Div([
                html.Div([
                    html.H2('PNL data grid' if spec.key == 'pnl' else 'Version comparison grid',
                            className='section-title'),
                    html.P('Stage Row Groups and Values above or beside the grid; click REFRESH to fetch their data.',
                           className='section-subtitle'),
                ]),
                html.Div('Select filters and click REFRESH data.',
                         id=id_('grid-status'), className='status-text'),
            ], className='grid-heading'),
            dcc.Loading(
                dag.AgGrid(
                    id=id_('grid'), rowData=[],
                    columnDefs=build_columns(spec),
                    defaultColDef=DEFAULT_COLUMN_DEF,
                    enableEnterpriseModules=True,
                    dashGridOptions=grid_options(),
                    # Built-in pivot-mode tool-panel checkboxes already edit
                    # rowGroup/aggFunc. No JS visibility-sync handlers needed.
                    className='ag-theme-alpine pnl-grid',
                    style={'height': 'min(84vh, 980px)', 'minHeight': '540px',
                           'width': '100%'},
                ),
                type='default', delay_show=400,
            ),
            html.P('Only selected Row Groups and Values are sent by REFRESH. '
                   'Adding a secondary group after refresh may show blank values until refreshed again. '
                   'XLSX exports the filtered underlying source data. Enterprise grouping '
                   'requires an AG Grid Enterprise license.', className='footnote'),
        ], className='grid-panel'),
        html.Div(id=id_('load-status'), className='assistive-status'),
        html.Div(id=id_('export-status'), className='export-status', role='status'),
    ], className='content')
