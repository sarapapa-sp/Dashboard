"""AG Grid: distinct REFERENTIAL and VALUE columns with native selection.

With pivotMode=True *and no actual pivot fields*, AG Grid's Columns-panel
checkboxes select Row Groups / Values rather than toggling visibility.
Grouping fields appear only under the single Business Hierarchy column.
"""
from __future__ import annotations

from report_config import FILTER_LABELS, ReportSpec


def build_referential_columns(spec: ReportSpec) -> list[dict]:
    """Ordered default and secondary grouping dimensions."""
    active = spec.default_referential_fields
    return [
        {
            'field': field,
            'headerName': FILTER_LABELS.get(field, field.replace('_', ' ').title()),
            'rowGroup': field in active,
            'rowGroupIndex': active.index(field) if field in active else None,
            # Never expose a second stand-alone referential column.
            # In pivot mode the checkbox reflects rowGroup, not `hide`.
            'hide': True,
            'enableRowGroup': True, 'enablePivot': False, 'enableValue': False,
            'filter': 'agTextColumnFilter', 'floatingFilter': False,
        }
        for field in spec.referential_fields
    ]


def build_value_columns(spec: ReportSpec) -> list[dict]:
    """Values independent from dimensions, including optional future values."""
    selected = set(spec.default_value_fields)
    return [
        {
            'field': field, 'headerName': label,
            'aggFunc': 'sum' if field in selected else None,
            'hide': field not in selected,
            'enableRowGroup': False, 'enablePivot': False, 'enableValue': True,
            'filter': False, 'floatingFilter': False,
            'suppressHeaderFilterButton': True, 'suppressHeaderMenuButton': True,
            'type': 'numericColumn', 'minWidth': 105, 'maxWidth': 170,
            'cellDataType': False,
            'valueFormatter': {'function': 'accountingFormatter(params)'},
            'cellClassRules': {
                'pnl-positive': 'Number(params.value) > 0',
                'pnl-negative': 'Number(params.value) < 0',
                'pnl-zero': 'Number(params.value) === 0',
            },
        }
        for field, label in spec.values
    ]


def build_columns(spec: ReportSpec, available_fields: set[str] | None = None) -> list[dict]:
    """Two named groups in the Columns tool panel (and grid header)."""
    del available_fields  # Compatibility with the original function signature.
    return [
        {'headerName': 'Referential Columns', 'groupId': 'referential',
         'children': build_referential_columns(spec)},
        {'headerName': 'Value Columns', 'groupId': 'measures',
         'children': build_value_columns(spec)},
    ]


DEFAULT_COLUMN_DEF = {
    'sortable': True, 'resizable': True, 'filter': False,
    'floatingFilter': False, 'minWidth': 105,
    'enableRowGroup': False, 'enablePivot': False, 'enableValue': False,
}


def grid_options() -> dict:
    return {
        # Pivot MODE is on for the tool-panel selection semantics; no column
        # is pivoted because every field has enablePivot=False and the pivot
        # UI is suppressed. It remains a row-group + SUM-values report.
        'pivotMode': True,
        'rowGroupPanelShow': 'always', 'pivotPanelShow': 'never',
        'groupDisplayType': 'singleColumn',
        'groupDefaultExpanded': 1, 'animateRows': False,
        # Group fields remain represented by the auto-group hierarchy only.
        'suppressMakeColumnVisibleAfterUnGroup': True,
        'suppressDragLeaveHidesColumns': True,
        'suppressAggFuncInHeader': True,
        'autoGroupColumnDef': {
            'headerName': 'Business Hierarchy', 'pinned': 'left',
            'minWidth': 240, 'width': 300,
            'cellRendererParams': {'suppressCount': True},
            'filter': 'agTextColumnFilter',
        },
        'sideBar': {'toolPanels': [
            {'id': 'columns', 'labelDefault': 'Columns', 'iconKey': 'columns',
             'toolPanel': 'agColumnsToolPanel',
             'toolPanelParams': {
                 'suppressPivotMode': True, 'suppressPivots': True,
             }},
            {'id': 'filters', 'labelDefault': 'Filters', 'iconKey': 'filter',
             'toolPanel': 'agFiltersToolPanel'},
        ], 'defaultToolPanel': None},
        'pagination': True, 'paginationPageSize': 100,
        'rowHeight': 30, 'headerHeight': 33, 'groupHeaderHeight': 30,
        'getRowId': {'function': 'params.data._row_id'},
    }
