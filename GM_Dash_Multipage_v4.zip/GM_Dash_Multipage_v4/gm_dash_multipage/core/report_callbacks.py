"""Page callbacks: REFRESH is the only trigger for backend grid aggregation.

Dropdowns and AG Grid columnState are staged in the browser. Refresh reads
those properties as State and updates ONLY rowData / status / applied export
snapshot. It NEVER overwrites columnDefs, columnState or dropdown values.
"""
from __future__ import annotations

import logging
from datetime import datetime

import pandas as pd
from dash import Input, Output, State, callback, dcc, html, no_update
from dash.exceptions import PreventUpdate

from core.data_service import (aggregate_for_grid, apply_filters, filter_options,
                               get_page_data)
from core.excel_export import write_excel
from core.report_page import cid, filter_id
from report_config import DEFAULT_ROW_GROUPS, FILTERS, OPTIONAL_FILTERS, ReportSpec

logger = logging.getLogger(__name__)


def handle_request(user_text: str | None, spec: ReportSpec) -> str:
    """Placeholder for future LLM/agentic request handler; does not affect grid."""
    message = (user_text or '').strip()
    if not message:
        return 'Enter a request before selecting Send.'
    return f'Request received on {spec.name}: {message}'


def selection_kwargs(values) -> dict:
    """Map FILTERS-order staged multi-select values onto data filter parameters."""
    fields = dict(zip(FILTERS, values, strict=True))
    fields['dates'] = fields.pop('cobdate')
    fields['portfolio'] = fields.pop('ptf')
    return fields


def selected_grid_columns(spec: ReportSpec, column_state: list[dict] | None
                          ) -> tuple[list[str], list[str]]:
    """Resolve the actual Row Groups and Values active at REFRESH time.

    AG Grid's `columnState` has one entry per field. The `rowGroup` flag and
    `rowGroupIndex` determine which referential fields are selected and in
    what order; `aggFunc` determines which numeric fields are in Values.
    A not-yet-mounted grid can supply None/[], in which case defaults apply.
    Once populated, a state with *zero* values is valid and must be respected.
    """
    if not column_state:
        return list(DEFAULT_ROW_GROUPS), list(spec.value_fields)

    allowed_groups = {'cobdate', *spec.dimensions, 'indicator', 'source'}
    allowed_values = set(spec.value_fields)
    groups: list[tuple[int, int, str]] = []
    values: list[str] = []
    seen_groups: set[str] = set()
    for pos, item in enumerate(column_state):
        if not isinstance(item, dict):
            continue
        field = item.get('colId') or item.get('field')
        if field in allowed_groups and item.get('rowGroup') is True and field not in seen_groups:
            index = item.get('rowGroupIndex')
            order = index if isinstance(index, (int, float)) and index >= 0 else pos
            groups.append((int(order), pos, field))
            seen_groups.add(field)
        if field in allowed_values and item.get('aggFunc') and field not in values:
            values.append(field)

    groups.sort(key=lambda record: (record[0], record[1]))
    # Always retain COB in backend groupby keys, even if its group chip is
    # removed, so records from separate COBs are never merged together.
    selected_groups = ['cobdate', *(field for _, _, field in groups if field != 'cobdate')]
    return selected_groups, values


def make_row_statistics(source_count: int, matching_count: int,
                        aggregated_count: int) -> html.Div:
    """Plain-text count box outside AG Grid."""
    reduction = 100 * (1 - aggregated_count / matching_count) if matching_count else 0.0
    cells = [
        ('Source rows', f'{source_count:,}'),
        ('Matching rows', f'{matching_count:,}'),
        ('Aggregated rows', f'{aggregated_count:,}'),
        ('Reduction', f'{reduction:.1f}%'),
    ]
    return html.Div([
        html.Span([html.Span(f'{label}: '), html.Strong(number)], className='row-summary-item')
        for label, number in cells
    ], className='row-summary-line')


def prepare_grid(df: pd.DataFrame, spec: ReportSpec, selections: dict,
                 group_fields: list[str] | None = None,
                 value_fields: list[str] | None = None
                 ) -> tuple[list[dict], int, int]:
    """Send ONLY the applied dimensions and numeric measures to the browser.

    Adding a secondary group after a REFRESH does *not* add that field to the
    previous rowData: its group appears blank until the next REFRESH button.
    """
    filtered = apply_filters(df, **selections)
    aggregated = aggregate_for_grid(filtered, spec,
                                    group_fields=group_fields,
                                    value_fields=value_fields)
    if aggregated.empty:
        return [], len(filtered), 0
    actual_values = set(spec.value_fields) if value_fields is None else set(value_fields)
    key_columns = [field for field in aggregated if field not in actual_values]
    hashes = pd.util.hash_pandas_object(aggregated[key_columns], index=False)
    aggregated['_row_id'] = hashes.astype(str)
    return aggregated.to_dict('records'), len(filtered), len(aggregated)


def register_report_callbacks(spec: ReportSpec) -> None:
    key = lambda suffix: cid(spec, suffix)
    dropdown = lambda field: filter_id(spec, field)

    # This runs when the page is first displayed. It populates filter OPTIONS
    # and a default COB but deliberately leaves AG Grid's rowData=[] intact.
    # It is not triggered by REFRESH and never changes grouped column choices.
    @callback(
        *[Output(dropdown(field), 'options') for field in FILTERS],
        Output(dropdown('cobdate'), 'value'),
        *[Output(dropdown(field), 'disabled') for field in OPTIONAL_FILTERS],
        Output(key('load-status'), 'children'),
        Input(key('filter-init'), 'data'),
        State(dropdown('cobdate'), 'value'),
    )
    def initialize_filters(_initialization_token, existing_dates):
        try:
            df, _ = get_page_data(spec, refresh=False)
            choices = [filter_options(df, field, descending=(field == 'cobdate'))
                       for field in FILTERS]
            dates = choices[0]
            # Keep a session-persisted COB choice if the user left and returned;
            # do not silently override deliberate selections with the latest.
            date_value = no_update if existing_dates else ([dates[0]['value']] if dates else [])
            disabled = [field not in df.columns for field in OPTIONAL_FILTERS]
            return (*choices, date_value, *disabled,
                    'Select filters and columns, then click REFRESH data.')
        except Exception as exc:
            logger.exception('Unable to load filter choices for %s', spec.key)
            return (*[[] for _ in FILTERS], no_update,
                    *[True for _ in OPTIONAL_FILTERS],
                    f'Unable to load filters for {spec.name}: {exc}')

    # The ONLY callback that changes the dataset in AG Grid. The selected
    # hierarchy and values are taken from columnState at the instant of click.
    # columnDefs, dashGridOptions, dropdown values and columnState are NEVER
    # outputs of this callback, so the client's selections survive refreshes.
    @callback(
        Output(key('grid'), 'rowData'),
        Output(key('grid-status'), 'children'),
        Output(key('row-stats'), 'children'),
        Output(key('applied-snapshot'), 'data'),
        Input(key('refresh'), 'n_clicks'),
        *[State(dropdown(field), 'value') for field in FILTERS],
        State(key('grid'), 'columnState'),
        prevent_initial_call=True,
    )
    def refresh_report(n_clicks, *staged_values_and_state):
        if not n_clicks:
            raise PreventUpdate
        staged_values = staged_values_and_state[:-1]
        column_state = staged_values_and_state[-1]
        try:
            df, sequence = get_page_data(spec, refresh=True)
            applied_filters = selection_kwargs(staged_values)
            group_fields, value_fields = selected_grid_columns(spec, column_state)
            # Ignore optional group columns absent in this source file.
            group_fields = [field for field in group_fields if field in df.columns]
            rows, matching, aggregated = prepare_grid(
                df, spec, applied_filters, group_fields, value_fields,
            )
            refreshed_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            snapshot = {
                'sequence': sequence, 'filters': applied_filters,
                'group_fields': group_fields, 'value_fields': value_fields,
            }
            status = (f'Refreshed at {refreshed_at} | '
                      f'{len(group_fields)} grouping columns, '
                      f'{len(value_fields)} numeric values')
            return (rows, status,
                    make_row_statistics(len(df), matching, aggregated), snapshot)
        except Exception as exc:
            logger.exception('Unable to refresh %s', spec.key)
            # Preserve the previous data, column choices and last successful
            # download snapshot in case the source is temporarily unavailable.
            return (no_update, f'Refresh failed: {exc}', no_update, no_update)

    @callback(
        Output(key('download'), 'data'),
        Output(key('export-status'), 'children'),
        Input(key('download-button'), 'n_clicks'),
        State(key('applied-snapshot'), 'data'),
        prevent_initial_call=True,
    )
    def download_filtered(n_clicks, snapshot):
        if not n_clicks:
            raise PreventUpdate
        if not snapshot:
            return no_update, 'Click REFRESH data first to apply the filters before exporting.'
        try:
            df, sequence = get_page_data(spec)
            if sequence != snapshot['sequence']:
                return no_update, ('The server snapshot changed after your last refresh. '
                                   'Click REFRESH data before exporting.')
            filtered = apply_filters(df, **snapshot['filters'])
            filename = f'{spec.key}_{datetime.now():%Y%m%d_%H%M%S}.xlsx'
            return (
                dcc.send_bytes(lambda buffer: write_excel(buffer, filtered, spec), filename),
                f'Exported {len(filtered):,} source records from the last applied filters to {filename}',
            )
        except Exception as exc:
            logger.exception('Excel export failed for %s', spec.key)
            return no_update, f'Export failed: {exc}'

    @callback(
        Output(key('request-response'), 'children'),
        Input(key('send-request'), 'n_clicks'), State(key('request'), 'value'),
        prevent_initial_call=True,
    )
    def handle_page_request(n_clicks, message):
        if not n_clicks:
            raise PreventUpdate
        try:
            return handle_request(message, spec)
        except Exception as exc:
            logger.exception('Request handling failed for %s', spec.key)
            return f'Request failed: {exc}'
