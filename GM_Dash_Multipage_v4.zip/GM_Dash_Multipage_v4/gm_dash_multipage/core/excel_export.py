"""Server-side XLSX export of *underlying filtered data* (not pivoted AG Grid rows)."""
from __future__ import annotations

import math
from datetime import date, datetime
from io import BytesIO

import pandas as pd
import xlsxwriter

from report_config import FILTER_LABELS, ReportSpec

# XLSX sheet has 1,048,576 rows; one is reserved for headers.
MAX_ROWS_PER_SHEET = 1_048_575


def write_excel(buffer: BytesIO, dataframe: pd.DataFrame, spec: ReportSpec) -> None:
    """Write exactly the server-side filtered rows; split overflow across sheets.

    Accept a BytesIO provided by dcc.send_bytes; constant_memory avoids retaining
    a second copy of the cell table while building the workbook.
    """
    fields = [field for field in dataframe.columns if field != '_row_id']
    title_map = dict(spec.values)
    headers = [title_map.get(field, FILTER_LABELS.get(field, field.replace('_', ' ').title()))
               for field in fields]

    with xlsxwriter.Workbook(buffer, {
        'constant_memory': True, 'strings_to_formulas': False, 'strings_to_urls': False,
    }) as book:
        header_style = book.add_format({
            'bold': True, 'font_color': '#FFFFFF', 'bg_color': '#166534',
            'bottom': 1, 'bottom_color': '#0F5132', 'valign': 'vcenter',
        })
        number_style = book.add_format({'num_format': '#,##0;[Red](#,##0);–'})
        date_style = book.add_format({'num_format': 'yyyy-mm-dd'})
        chunks = max(1, math.ceil(len(dataframe) / MAX_ROWS_PER_SHEET))
        # itertuples keeps extra copies small; index=False preserves file order.
        iterator = dataframe[fields].itertuples(index=False, name=None)
        for chunk in range(chunks):
            sheet = book.add_worksheet('Filtered Data' if chunks == 1 else f'Data {chunk+1}')
            sheet.freeze_panes(1, 0)
            sheet.set_row(0, 27)
            for col, (field, header) in enumerate(zip(fields, headers)):
                sheet.write_string(0, col, header, header_style)
                sheet.set_column(col, col, 13 if field in spec.value_fields else 18,
                                 number_style if field in spec.value_fields else None)
            capacity = min(MAX_ROWS_PER_SHEET, len(dataframe) - chunk * MAX_ROWS_PER_SHEET)
            for excel_row in range(1, capacity + 1):
                values = next(iterator)
                for col, (field, value) in enumerate(zip(fields, values)):
                    if value is None or (not isinstance(value, str) and pd.isna(value)):
                        continue
                    if field in spec.value_fields:
                        sheet.write_number(excel_row, col, float(value), number_style)
                    elif isinstance(value, (date, datetime)):
                        sheet.write_datetime(excel_row, col, value, date_style)
                    else:
                        # write_string ensures even '=...', '+...' or '@...' are text.
                        sheet.write_string(excel_row, col, str(value))
            if capacity:
                sheet.autofilter(0, 0, capacity, len(fields)-1)


def to_excel_bytes(dataframe: pd.DataFrame, spec: ReportSpec) -> bytes:
    buffer = BytesIO()
    write_excel(buffer, dataframe, spec)
    return buffer.getvalue()
