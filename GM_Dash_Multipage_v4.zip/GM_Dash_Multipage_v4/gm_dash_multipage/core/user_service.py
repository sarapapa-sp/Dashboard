"""Current user identity adapter; replace this stub for your JupyterHub/SSO environment."""
from __future__ import annotations


def get_current_user() -> tuple[str, str]:
    """Return (user_id, username). Static demonstration values only.

    In production, integrate your trusted server identity mapping here.
    Never accept the username or user ID from an unvalidated browser field.
    """
    return 'GM-DEMO-001', 'Demo Analyst'
