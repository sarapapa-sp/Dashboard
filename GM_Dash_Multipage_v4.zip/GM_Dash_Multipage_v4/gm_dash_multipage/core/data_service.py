"""One data source per page; fast shared server-side caches per Python worker."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from threading import RLock
from time import monotonic

import pandas as pd

from report_config import ROOT, ReportSpec

logger = logging.getLogger(__name__)
_lock = RLock()
_cache: dict[str, '_Entry'] = {}

# Optional input aliases, matched case-insensitively (space/hyphen normalized).
ALIASES = {
    'cob_date': 'cobdate', 'cob': 'cobdate', 'cob date': 'cobdate',
    'portfolio': 'ptf', 'activity_l5': 'activityl5',
    'sub_business_line': 'subbusinessline', 'activity_l1': 'activityl1',
}


@dataclass
class _Entry:
    dataframe: pd.DataFrame
    source_token: tuple
    updated_at: float
    sequence: int


def source_path(spec: ReportSpec) -> Path:
    supplied = os.environ.get(spec.source_env, '').strip()
    path = Path(supplied).expanduser() if supplied else ROOT / spec.sample_path
    return path.resolve()


def _source_token(path: Path) -> tuple:
    stat = path.stat()  # raises FileNotFoundError with an actionable path
    return (str(path), stat.st_mtime_ns, stat.st_size)


def _read_file(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == '.csv':
        return pd.read_csv(path, low_memory=False)
    if suffix in ('.xlsx', '.xlsm'):
        return pd.read_excel(path, engine='openpyxl')
    if suffix == '.parquet':
        return pd.read_parquet(path)  # requires optional pyarrow
    raise ValueError(f'Unsupported file: {path.name}. Use .csv, .xlsx, .xlsm or .parquet.')


def request_page_data(spec: ReportSpec) -> pd.DataFrame:
    """Swap just this function when your existing data_service is not file based.

    For example:
        if spec.key == 'pnl':
            from legacy_data_service import request_data
            return request_data()
    """
    return _read_file(source_path(spec))


def normalize_data(df: pd.DataFrame, spec: ReportSpec) -> pd.DataFrame:
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f'{spec.name}: data service must return a pandas DataFrame')

    # Canonicalize all source columns (e.g. Daily_V0 -> daily_v0).
    rename: dict = {}
    seen: set[str] = set()
    for original in df.columns:
        compact = str(original).strip().lower().replace('-', '_').replace(' ', '_')
        canonical = ALIASES.get(compact, compact)
        if canonical in seen:
            raise ValueError(f'{spec.name}: duplicate column after normalization: {canonical}')
        seen.add(canonical)
        rename[original] = canonical
    df = df.rename(columns=rename)

    missing = [name for name in spec.required_columns if name not in df.columns]
    if missing:
        raise ValueError(f'{spec.name}: missing required columns: {missing}')

    # Optional filter fields remain optional to preserve legacy datasets.
    selected = list(dict.fromkeys((*spec.required_columns, 'indicator', 'source')))
    df = df[[c for c in selected if c in df.columns]].copy()
    formatted_dates = pd.to_datetime(df['cobdate'], errors='coerce')
    df['cobdate'] = formatted_dates.dt.strftime('%Y-%m-%d').fillna('(Invalid date)')

    for field in spec.dimensions:
        df[field] = df[field].fillna('(Blank)').astype(str)
    for field in ('indicator', 'source'):
        if field in df:
            df[field] = df[field].fillna('(Blank)').astype(str)
    for field in spec.value_fields:
        df[field] = pd.to_numeric(df[field], errors='coerce').fillna(0)
    return df


def get_page_data(spec: ReportSpec, *, refresh: bool = False) -> tuple[pd.DataFrame, int]:
    """Return the current worker's snapshot; reload only on explicit refresh.

    The first request populates the filter lists. Subsequent calls, including
    XLSX downloads, reuse the *same* normalized data even when a file changes
    on disk. Clicking Refresh data passes refresh=True and replaces the snapshot.

    Cache scope is one Python worker (not distributed and not per-user). A
    session's applied version is checked before export to prevent silently
    exporting data from a newer shared snapshot. For multi-worker production,
    use a shared immutable snapshot store and per-session snapshot token.
    """
    with _lock:
        previous = _cache.get(spec.key)
        if previous is not None and not refresh:
            return previous.dataframe, previous.sequence

    start = monotonic()
    path = source_path(spec)
    token = _source_token(path)
    data = normalize_data(request_page_data(spec), spec)
    with _lock:
        prior = _cache.get(spec.key)
        sequence = 1 + (prior.sequence if prior else 0)
        _cache[spec.key] = _Entry(data, token, monotonic(), sequence)
    logger.info('Loaded %s: %s records, source=%s, seconds=%.2f',
                spec.key, len(data), path.name, monotonic() - start)
    return data, sequence


def clear_cache() -> None:
    with _lock:
        _cache.clear()


def _selected_values(value) -> list[str]:
    """A cleared multi-dropdown means all values, not an empty dataset."""
    if value is None:
        return []
    if isinstance(value, str):
        if not value:
            return []
        return [value]
    return [str(item) for item in value if item is not None]


def apply_filters(df: pd.DataFrame, *, dates=None, gbl=None,
                  subbusinessline=None, activityl1=None, activityl5=None,
                  portfolio=None, indicator=None, source=None) -> pd.DataFrame:
    """Exact-match multiselects. Shared by the grid AND underlying-row XLSX.

    Portfolio was previously a free-text *contains* search. It is now a
    searchable multi-dropdown and therefore uses exact selected portfolio IDs.
    """
    selections = (
        ('cobdate', dates), ('gbl', gbl), ('subbusinessline', subbusinessline),
        ('activityl1', activityl1), ('activityl5', activityl5),
        ('ptf', portfolio), ('indicator', indicator), ('source', source),
    )
    for field, raw_selection in selections:
        chosen = _selected_values(raw_selection)
        if chosen and field in df.columns:
            df = df.loc[df[field].isin(chosen)]
    return df


def aggregate_for_grid(filtered: pd.DataFrame, spec: ReportSpec, *,
                       group_fields: list[str] | tuple[str, ...] | None = None,
                       value_fields: list[str] | tuple[str, ...] | None = None) -> pd.DataFrame:
    """Aggregate ONLY columns applied by the AG Grid REFRESH button.

    With no explicit fields, the function preserves v2/v3 full-leaf-grain
    behavior for callers that used the legacy API. The page's refresh callback
    supplies both lists from the current ``columnState`` instead.

    COB is an invariant key, even if a user temporarily removes its visible
    row-group chip. This prevents values from different COB dates merging.
    """
    if group_fields is None:
        group_fields = [
            'cobdate', *spec.dimensions,
            *(field for field in ('indicator', 'source') if field in filtered.columns),
        ]
    if value_fields is None:
        value_fields = list(spec.value_fields)

    permitted_groups = {'cobdate', *spec.dimensions, 'indicator', 'source'}
    group_fields = list(dict.fromkeys(['cobdate', *group_fields]))
    if any(field not in permitted_groups for field in group_fields):
        raise ValueError('Unsupported grouping field supplied to aggregate_for_grid')
    group_fields = [field for field in group_fields if field in filtered.columns]
    value_fields = list(dict.fromkeys(value_fields))
    if any(field not in spec.value_fields for field in value_fields):
        raise ValueError('Unsupported value field supplied to aggregate_for_grid')
    output_columns = [*group_fields, *value_fields]
    if filtered.empty:
        return pd.DataFrame(columns=output_columns)
    if not value_fields:
        return (filtered.groupby(group_fields, as_index=False, sort=False,
                                 dropna=False).size()
                .drop(columns='size'))
    return filtered.groupby(group_fields, as_index=False, sort=False,
                            dropna=False)[value_fields].sum()


def filter_options(df: pd.DataFrame, field: str, *, descending: bool = False) -> list[dict]:
    if field not in df:
        return []
    entries = sorted((str(v) for v in df[field].dropna().unique()), reverse=descending)
    if field == 'cobdate':
        entries = [x for x in entries if x != '(Invalid date)']
    return [{'label': value, 'value': value} for value in entries]
