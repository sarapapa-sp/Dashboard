"""Declarative page specs and the eight shared multiselect filters."""
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent

COMMON_DIMENSIONS = (
    'gbl', 'subbusinessline', 'activityl1', 'activityl5', 'ptf',
)

# Initial AG Grid row hierarchy. Secondary dimensions are offered in the
# Columns panel but do not enter the server aggregation until REFRESH.
DEFAULT_ROW_GROUPS = ('cobdate', 'gbl', 'subbusinessline', 'activityl1')

# Ordered lists are deliberately separate from the eight FILTERS.
# These control AG Grid Row Groups; filters do NOT automatically add grouping.
DEFAULT_REFERENTIAL_COLUMNS = DEFAULT_ROW_GROUPS
SECONDARY_REFERENTIAL_COLUMNS = ('activityl5', 'ptf', 'indicator', 'source')
REFERENTIAL_COLUMNS = (*DEFAULT_REFERENTIAL_COLUMNS, *SECONDARY_REFERENTIAL_COLUMNS)

# Four filters on each row at desktop width. Edit this tuple to change the
# shared filter order across ALL pages (see docs/ADD_A_PAGE.md).
FILTERS = (
    'cobdate', 'gbl', 'subbusinessline', 'activityl1',
    'activityl5', 'ptf', 'indicator', 'source',
)
FILTER_LABELS = {
    'cobdate': 'COB Date',
    'gbl': 'GBL',
    'subbusinessline': 'Sub-Business Line',
    'activityl1': 'Activity L1',
    'activityl5': 'Activity L5',
    'ptf': 'Portfolio',
    'indicator': 'Indicator',
    'source': 'Source',
}
OPTIONAL_FILTERS = ('indicator', 'source')


@dataclass(frozen=True)
class ReportSpec:
    key: str
    name: str
    path: str
    title: str
    subtitle: str
    source_env: str
    sample_path: str
    values: tuple[tuple[str, str], ...]
    dimensions: tuple[str, ...] = COMMON_DIMENSIONS
    # Explicit per-page defaults. Remaining measures are available in the
    # Columns panel but are not included until selected and REFRESH is clicked.
    default_values: tuple[str, ...] | None = None

    @property
    def referential_fields(self) -> tuple[str, ...]:
        """All selectable grouping columns in display order."""
        return tuple(dict.fromkeys((*DEFAULT_REFERENTIAL_COLUMNS,
                                    *self.dimensions,
                                    *SECONDARY_REFERENTIAL_COLUMNS)))

    @property
    def default_referential_fields(self) -> tuple[str, ...]:
        return tuple(f for f in DEFAULT_REFERENTIAL_COLUMNS if f in self.referential_fields)

    @property
    def secondary_referential_fields(self) -> tuple[str, ...]:
        return tuple(f for f in self.referential_fields if f not in self.default_referential_fields)

    @property
    def default_value_fields(self) -> tuple[str, ...]:
        if self.default_values is None:
            return self.value_fields
        unknown = set(self.default_values) - set(self.value_fields)
        if unknown:
            raise ValueError(f'{self.key}: unknown default value columns: {sorted(unknown)}')
        return tuple(dict.fromkeys(self.default_values))

    @property
    def secondary_value_fields(self) -> tuple[str, ...]:
        return tuple(f for f in self.value_fields if f not in self.default_value_fields)

    @property
    def required_columns(self) -> tuple[str, ...]:
        return ('cobdate', *self.dimensions, *(field for field, _ in self.values))

    @property
    def value_fields(self) -> tuple[str, ...]:
        return tuple(field for field, _ in self.values)


PNL = ReportSpec(
    key='pnl', name='PNL Report', path='/',
    title='Hierarchical PNL Report',
    subtitle='Review daily, MTD, YTD and prior-year performance by business hierarchy.',
    source_env='DASH_PNL_FILE', sample_path='data/sample_pnl.xlsx',
    values=(('daily', 'Daily PNL'), ('mtd', 'MTD PNL'),
            ('ytd', 'YTD PNL'), ('ytdn1', 'YTD N-1 PNL')),
    default_values=('daily', 'mtd', 'ytd'),
)

VERSIONS = ReportSpec(
    key='versions', name='Version Comparison', path='/version-comparison',
    title='Version Comparison',
    subtitle='Compare V0, V1 and V3 using the same filters and business hierarchy.',
    source_env='DASH_VERSIONS_FILE', sample_path='data/sample_versions.xlsx',
    values=(
        ('daily_v0', 'Daily_V0'), ('mtd_v0', 'MTD_V0'), ('ytd_v0', 'YTD_V0'),
        ('daily_v1', 'Daily_V1'), ('mtd_v1', 'MTD_V1'), ('ytd_v1', 'YTD_V1'),
        ('daily_v3', 'Daily_V3'), ('mtd_v3', 'MTD_V3'), ('ytd_v3', 'YTD_V3'),
    ),
    # The V0 trio is the starting selection; V1/V3 can be added later.
    default_values=('daily_v0', 'mtd_v0', 'ytd_v0'),
)
