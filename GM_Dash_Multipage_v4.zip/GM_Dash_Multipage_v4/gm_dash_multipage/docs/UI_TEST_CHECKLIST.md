# UI acceptance checklist — v4

Run `python app.py` with an AG Grid Enterprise license and the bundled sample
workbooks. These checks require a real browser: backend unit tests alone
cannot verify client-side AG Grid drag/drop state behavior.

## Initial load (test both screens)

- [ ] Navigate to `/` and `/version-comparison` from the left sidebar.
- [ ] Eight searchable multiselect filters appear in two rows of four.
- [ ] Latest COB is preselected (sample: 2026-11-19).
- [ ] Grid is initially **blank**, with no underlying data rows.
- [ ] The Row Groups zone initially has exactly **COB Date, GBL,
      Sub-Business Line, Activity L1**, in that order.
- [ ] Activity L5, Portfolio, Indicator and Source are *not* initially
      selected as Row Groups.
- [ ] Values initially holds 4 PNL measures on Page 1 and 9 version
      measures on Page 2.
- [ ] There is **no "Drag here to set column labels"** / pivot drop zone.
- [ ] Row Groups remain visible above AG Grid; signed-in user details remain
      visible in the footer.

## Refresh/filter retention

- [ ] Change GBL and Portfolio selections before clicking REFRESH: AG Grid
      remains blank and counts unchanged.
- [ ] REFRESH loads the selected COB and filters, without clearing or
      reselecting any dropdown.
- [ ] With sample data latest COB only and default groups, Matching=36 and
      Aggregated=6 (Source=108).
- [ ] After REFRESH, change the GBL filter without clicking REFRESH: rows,
      counts and last-applied XLSX data remain as before.
- [ ] REFRESH again: the new GBL filter applies, and chosen dropdown values
      stay visible.

## Column-state retention and missing-field behavior

- [ ] After first REFRESH, add Activity L5 into Row Groups but do **not**
      refresh. Its new grouping level contains blank labels; no source
      rows/metrics are fetched.
- [ ] Click REFRESH: Activity L5 labels now show values and aggregated
      row count reflects the new grouping grain.
- [ ] Remove YTD_V3 (Page 2) from Values and add Portfolio as a Row Group.
      Click REFRESH: all selected row-group chips stay selected, YTD_V3 stays
      removed, and Portfolio labels are now populated.
- [ ] Drag a row-group chip to change its order, then click REFRESH: new order
      stays; the callback must not reset `columnDefs` or `columnState`.
- [ ] Switch COB date selection away from latest and REFRESH: chosen date
      remains selected and loaded data reflect it.
- [ ] Unselect all Values, REFRESH, and verify there is no unsupported
      measure in rowData (group-only display is allowed).
- [ ] No unwanted row-count suffix appears beside group names.
- [ ] Font sizes are readable (12px body/group and 11px headers); row height
      is 30px and the grid keeps its taller viewport.

## Export/errors/navigation

- [ ] Before initial REFRESH, DOWNLOAD displays a request to refresh first.
- [ ] After REFRESH, changing filters without refreshing does **not** change
      exported XLSX selections: export matches the last applied snapshot.
- [ ] The exported Excel contains original filtered source detail, not just
      the grouped grid rows.
- [ ] Missing/invalid data source on a subsequent REFRESH displays an error
      while retaining previous rows and selections.
- [ ] Repeat test on both pages. Check the user footer and sidebar state.

Run automated regressions:

```bash
python -m pytest -q
python -m compileall -q app.py report_config.py core pages
```
