# Data integration and deployment — v3

## 1. Environment configuration

Use `DASH_PNL_FILE` for the PNL page and `DASH_VERSIONS_FILE` for the comparison page. Paths may target CSV, XLSX, XLSM or Parquet (optional `pyarrow`). If a variable is missing, the bundled synthetic workbook is loaded.

`DASH_HOST`, `DASH_PORT` and `DASH_DEBUG` also configure `app.py`. `.env.example` illustrates these values; the app does not load `.env` automatically.

## 2. Input schema

Required common fields:

```text
cobdate, gbl, subbusinessline, activityl1, activityl5, ptf
```

Optional filter fields: `indicator`, `source`.

PNL values: `daily`, `mtd`, `ytd`, `ytdn1`.

Comparison values: `Daily_V0, MTD_V0, YTD_V0, Daily_V1, MTD_V1, YTD_V1, Daily_V3, MTD_V3, YTD_V3` (internally normalized to lowercase).

Aliases include `COB_Date -> cobdate`, `Portfolio -> ptf`, `Activity_L5 -> activityl5`. Dates are converted to ISO `YYYY-MM-DD`; blank business dimensions become `(Blank)`; non-numeric measure cells become zero.

## 3. Eight shared dropdowns

Four per desktop row:

- Row 1: COB Date, GBL, Sub-Business Line, Activity L1.
- Row 2: Activity L5, Portfolio, Indicator, Source.

Each is a searchable `dcc.Dropdown` with `multi=True`. A filter matches **any** selected item (OR); combinations of different filters use **AND**. Clearing a dropdown means All. COB Date defaults to latest date on first visit. Indicator/Source are disabled when those fields are not supplied.

## 4. Explicit refresh and selected-column lifecycle (v4)

The `core/report_callbacks.py` file separates filter initialization from
server-side REFRESH. Filter dropdowns and the AG Grid Columns panel hold staged
user choices in the browser. REFRESH reads the eight dropdowns and
`grid.columnState` as Dash **States**, with only the REFRESH button as Input.

- Initial page entry: reads source only to provide filter choices and default
  latest COB; `rowData` is blank. AG Grid has COB/GBL/Sub Business Line/Activity L1
  grouped by default and the report's numeric measures active.
- User edits filters or Row Groups/Values: does not re-read or re-aggregate
  server data. AG Grid may reorganize existing records locally.
- REFRESH: force-read source, filter, determine actual selected grouping and
  numeric columns from columnState, group by only those columns, then update
  `rowData` and counts. **Does not reset any dropdown or column definitions.**
- A secondary column added after an earlier refresh is absent from old rowData
  and will show empty group labels until the next refresh.
- The Row Groups drop zone remains; `pivotMode=False` and
  `pivotPanelShow='never'` remove the Column Labels/pivot drop zone.
- Download: uses the last applied filters and the worker cache, not staged edits.

## 5. Selected aggregation grain and counts

On initial REFRESH, Pandas groups by `cobdate`, `gbl`, `subbusinessline`,
`activityl1` (only) and sums the report's default active Values. Other
referential columns such as `activityl5`, `ptf`, `indicator`, and `source` are
**excluded from the grid payload** until explicitly selected and refreshed.
COB is a mandatory backend key to prevent combining separate dates.

Removing a numeric measure from the AG Grid Values panel makes `aggFunc=None`
in `columnState`, so it is excluded on the next refresh. These fields must
be additive; ratios and prices require different aggregation logic.

The source row count, matching (filtered) row count, aggregated row count and
reduction percentage are shown in a simple text box **beneath** REFRESH and
DOWNLOAD, outside AG Grid. For sample data/latest COB the counts are
`108 / 36 / 6` using the four default groups.

## 6. Excel download semantics

`core/report_callbacks.py::download_filtered()` takes the last applied `dcc.Store` snapshot and obtains the cached source. `apply_filters()` produces matching original rows. `core/excel_export.py::write_excel()` writes these into XLSX; it deliberately does not call `aggregate_for_grid()`.

It therefore **does not** reproduce the visible AG Grid pivot, row groups, current pagination, client-side sorting or sidebar filters. The goal is to preserve source-level detail for reconciliation. Excel limits are handled by splitting output sheets; long exports still consume server IO and network bandwidth.

## 7. User identity integration

`core/user_service.py` contains:

```python
def get_current_user() -> tuple[str, str]:
    return 'GM-DEMO-001', 'Demo Analyst'
```

Replace with trusted corporate identity extraction. For example, in a JupyterHub or internal server environment, call the authorized server API for user ID, map the ID to a username from your directory/Excel mapping and return `(userid, username)`. The app uses this provider for its bottom footer. Do **not** use a browser-supplied identity for authentication or access controls. This footer is informational only.

## 8. Deployment and scaling cautions

1. **Cache scope:** `_cache` is a Python-process-local dictionary protected by a thread lock. Each worker has its own snapshot and sequence. Browser `dcc.Store` is per page session, but server cache is not per user. Cross-worker exports can fail version checks (safer than returning the wrong snapshot). For multiworker enterprise deployment, use a shared immutable snapshot store keyed by version/report/session, or a central query service with stable snapshot IDs.
2. **Scalability:** Pandas reads the full source into worker memory and Dash sends all aggregated grid rows into `rowData`. For millions of source records, prefer query pushdown (SQL, DuckDB, Polars/Parquet, Arrow) and AG Grid Server-Side Row Model when warranted.
3. **High-cardinality dimensions:** All distinct Portfolio choices are currently returned to the browser. Searchable dropdowns are fine for demonstrations; very high cardinality sources benefit from server-side option search.
4. **Concurrency:** A simultaneous REFRESH may update a shared worker snapshot used by another session, causing the older session's export to be blocked until it refreshes.
5. **Licensing:** Grouping/pivoting relies on AG Grid Enterprise. Configure the applicable license for your corporate deployment.
6. **Security:** Limit accessible input paths, validate internal loader responses, keep app behind corporate auth, and validate/log any future agentic command endpoints.
7. **Testing:** Run `python -m pytest -q` and use `docs/UI_TEST_CHECKLIST.md` for actual browser acceptance testing.

## 9. Diagnostics

- No rows after page navigation? This is expected until **REFRESH data** is clicked.
- Filters not showing? Check file path, required columns, aliases and `load-status` beneath the grid.
- Group hierarchy missing? Check AG Grid Enterprise license and `rowGroupPanelShow='always'`; look at the drop zone immediately above table headers.
- Filter chip icon above the label? Check `.Select-value`/`.Select-value-icon`/`.Select-value-label` rules in `assets/00-style.css`, and browser's loaded stylesheet.
- Export differs from current pending filters? Expected until REFRESH applies the selections.
- Export blocked due to stale source version? Another request updated this worker's cache; click REFRESH, then DOWNLOAD.
- Need a new page? Read `docs/ADD_A_PAGE.md` for a two-file registration process.

See `docs/TECHNICAL_ARCHITECTURE.md` for a complete folder-by-folder and function-by-function explanation.
