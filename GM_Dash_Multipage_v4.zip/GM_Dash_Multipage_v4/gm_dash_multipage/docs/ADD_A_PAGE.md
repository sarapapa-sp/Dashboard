# Adding a report page — v3

The application uses a **declarative `ReportSpec` + a small Dash Pages module**. New pages automatically inherit the left sidebar, static user footer, eight searchable filters (two rows of four), REFRESH-only data/spec updates, inline counts, Row Groups panel (pivot panel hidden), and XLSX export.

## Step 1 — Add a ReportSpec to `report_config.py`

```python
FORECAST = ReportSpec(
    key='forecast',                   # unique prefix for every component ID
    name='Forecast',                  # sidebar navigation label
    path='/forecast',                 # URL
    title='Forecast vs Actual',       # visible report page heading
    subtitle='Actual versus budget by hierarchy.',
    source_env='DASH_FORECAST_FILE',  # environment variable holding source path
    sample_path='data/sample_forecast.xlsx',
    values=(('actual', 'Actual'), ('budget', 'Budget'), ('variance', 'Variance')),
    # Default dimensions are COMMON_DIMENSIONS; customize if necessary.
)
```

By default the required columns will be `cobdate, gbl, subbusinessline, activityl1, activityl5, ptf, actual, budget, variance`. `indicator` and `source` remain optional. The `values` columns must be additive if they are to use `groupby().sum()`.

## Step 2 — Register the page

Create `pages/forecast.py`:

```python
import dash
from report_config import FORECAST
from core.report_page import layout as make_layout
from core.report_callbacks import register_report_callbacks

dash.register_page(__name__, path=FORECAST.path, name=FORECAST.name, order=2)
layout = make_layout(FORECAST)
register_report_callbacks(FORECAST)
```

The navigation sidebar is generated from Dash's page registry. **No change to `app.py` is required** for routes, sidebar styling, or the user footer.

## Step 3 — Provide your data

`data/sample_forecast.xlsx` is only used when `DASH_FORECAST_FILE` is absent. Recommended production setup:

```powershell
# Windows PowerShell
$env:DASH_FORECAST_FILE = 'C:\Reports\forecast.xlsx'
python app.py
```

```bash
# Linux / macOS
export DASH_FORECAST_FILE='/srv/reports/forecast.csv'
python app.py
```

Supported formats: CSV, XLSX, XLSM and Parquet (requires `pyarrow`). Column names are case-insensitive, with aliases for common date/portfolio/activity names in `core/data_service.py`. Add any missing source field aliases there.

## Step 4 — Verify selected-column refresh behavior

1. Open `/forecast`: eight dropdowns obtain their choices and latest COB Date is preselected; the **grid remains blank**.
2. Choose GBL, Portfolio and any other fields; nothing changes in the grid until **REFRESH data** is clicked.
3. Click **REFRESH data**: the backend rereads the file, applies selections, runs `groupby().sum()`, sends only the currently selected Row Groups and Values in `rowData` (without resetting `columnDefs`/filter selections), and updates inline row-count text.
4. Drag the row-group chips in the hierarchy panel at the top of AG Grid as desired. This modifies **client-side** presentation, not the server source snapshot.
5. Change a dropdown again. The grid stays unchanged. Clicking **DOWNLOAD XLSX** exports the last **applied**, not pending, filter selections.
6. Click REFRESH and then DOWNLOAD to export the new selection. Check that source records rather than aggregated grid rows are exported.

## Step 5 — Optional customizations

| Need | File |
|---|---|
| Different columns/labels | `ReportSpec.values` in `report_config.py` |
| More or fewer shared filters | `FILTERS`/`FILTER_LABELS` in `report_config.py`, mapping in `report_callbacks.selection_kwargs`, and filtering in `data_service.apply_filters` |
| Special source loader | `core/data_service.py::request_page_data()` (implement a reliable cache key) |
| Special aggregation grain | `ReportSpec.dimensions`, `core/data_service.aggregate_for_grid()` |
| Grid default groups and Values | `core/grid_config.py` |
| Special export workbook | `core/excel_export.py`, `download_filtered()` |
| Filter chips or sidebar look | `assets/00-style.css` |
| Current user ID/username | `core/user_service.py::get_current_user()` |
| Dashboard footer layout | `app.py::serve_layout()` |

**Caution:** This code has an application-wide, per-Python-worker cache keyed by `ReportSpec.key`. For production multiworker, multiuser snapshots, use a shared immutable cache with session-specific version tokens to avoid export-version mismatch; see `INTEGRATION.md`.

Detailed function descriptions are in `TECHNICAL_ARCHITECTURE.md`; an end-to-end browser checklist is in `UI_TEST_CHECKLIST.md`.
