# Changelog — v2

## Filter area
- Replaced the six mixed single/multi filters with **eight searchable multi-select dropdowns**.
- Added Sub-Business Line and Activity L1.
- Changed Portfolio from substring input to exact-match searchable multi-select.
- Added corporate-styled selected-value chips, dropdown options, focus state,
  taller selectable controls and scrollable selections.
- Desktop: 4 filters per row, exactly 2 rows. Narrow viewport: responsive 2 columns.

## Layout/navigation
- Replaced horizontal page tabs with a fixed-height dedicated **left sidebar**.
- Auto-populated sidebar from Dash page registry, with an active-page highlight.
- Sidebar navigation scrolls as more report pages are added.

## Aggregation/counters
- New `aggregate_for_grid()` in `core/data_service.py` groups by COB + business
  dimension fields + optional Indicator/Source, summing report value columns.
- New `prepare_grid()` in `core/report_callbacks.py` sends only pre-aggregated
  records and stable group-key-derived IDs to the client grid.
- Displays Source rows, Matching source rows, Aggregated grid rows and Rows reduced.
- Existing Excel download intentionally remains underlying source-row detail.

## Existing behavior retained
- Numeric grid value columns have no header filters, including pivot results.
- `suppressCount=True` removes AG Grid group label counts.
- Separate page files, source configurations, and nine V0/V1/V3 numeric fields.
- Agentic command field remains a placeholder for future integration.

## Verification
- Nine data/export tests passed under the available Python environment.
- Python source compiles.
- **Live Dash UI not exercised**: Dash packages were not available in the
  build environment, and its package registry was unreachable. Install
  `requirements.txt` on your local server to validate the browser UI.
