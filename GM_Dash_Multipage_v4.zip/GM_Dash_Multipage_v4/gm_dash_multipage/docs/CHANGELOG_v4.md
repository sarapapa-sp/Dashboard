# Changelog — v4 (REFRESH behavior correction)

- Initial grid stays empty (`rowData=[]`) with *four* default referential groups
  `COB Date / GBL / Sub-Business Line / Activity L1`. Secondary groups are
  inactive. All numeric values on the relevant page are active by default.
- REFRESH reads `grid.columnState` as a **State**, using `rowGroupIndex`,
  `rowGroup`, and `aggFunc` to decide the **server-side aggregation grain**.
- Only active groups and values are sent to AG Grid. Newly added secondary
  groups remain blank until the next explicit refresh; deselected values
  are not serialized into the newly refreshed data.
- Removed all `columnDefs`, `defaultColDef`, `dashGridOptions` and dropdown
  `value` outputs from the REFRESH callback to preserve staged user choices.
- Filter-option initialization is separate and runs on page entry; the date
  selector defaults to latest COB unless the user has an existing selection.
- Removed the Column Labels/pivot drop area: `pivotMode=False`,
  `pivotPanelShow='never'`. Kept Row Groups drop zone and Columns panel.
- Increased AG Grid text from 10px to 12px, headers to 11px and rows to 30px.
- Kept two-page navigation, eight multiselect controls, snapshot-locked source
  XLSX download, external row-count text and user footer.
- Added regression tests and a dedicated technical refresh behavior guide.
