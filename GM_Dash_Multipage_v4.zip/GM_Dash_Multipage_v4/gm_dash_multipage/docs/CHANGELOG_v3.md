# Changelog — v3

## Required UI updates

1. **Multi-select alignment:** selected-value chip icon/box and label are now kept on the same line; CSS also aligns AG Grid Columns-panel checkboxes and labels horizontally.
2. **Refresh-only data and spec:** dropdowns are `State`, never data-refresh `Input`. Initial page rendering populates selector options only; AG Grid remains empty until REFRESH. Clicking REFRESH reloads the source, validates selected filters, aggregates source records and updates `rowData`, `columnDefs`, `dashGridOptions`, `defaultColDef`, row summary and applied filter snapshot.
3. **Stats relocated:** simple Source/Matching/Aggregated/Reduction text box directly under REFRESH and DOWNLOAD. Removed KPI cards from AG Grid region.
4. **Row-group hierarchy restored:** `rowGroupPanelShow='always'` and `pivotPanelShow='always'` above AG Grid.
5. **Grid readability:** height raised to `min(84vh, 980px)` (minimum 540 px), fonts reduced to 10 px for group/value rows and 9 px for headers, row height reduced to 25 px.
6. **User footer:** added `core/user_service.py::get_current_user()` -> `(user_id, username)`, currently static demo values; both displayed in bottom footer.

## Data/export correctness

- Cached DataFrame is not silently reloaded when the source file changes; only `refresh=True` replaces it.
- DOWNLOAD uses the **last applied REFRESH filters**, not pending selections; requires REFRESH before first export.
- Download validates the cached source sequence before exporting to avoid quietly using a newer worker-local source snapshot.
- Excel display labels now honor the eight shared filter labels (e.g. `GBL` rather than `Gbl`, `COB Date` rather than `Cobdate`).

## Documentation and tests

- New detailed `docs/TECHNICAL_ARCHITECTURE.md`, file-by-file overview, callback map, caching, lifecycle, production caveats.
- New `docs/UI_TEST_CHECKLIST.md` to manually verify Enterprise AG Grid behavior.
- Updated `docs/ADD_A_PAGE.md`, `docs/INTEGRATION.md`, root `README.md`.
- Added three v3 tests for refresh/cache, callback triggers/export and user/panel options; 12 tests total.

## Important interpretation

REFRESH is the sole trigger for **server-side** source reload, Pandas aggregation, and declarative AG Grid specs. Dragging a row-group column or clicking the Columns tool panel still updates **AG Grid's client-side presentation** immediately; AG Grid itself controls those interactions. To stage *client-side* drag operations until REFRESH, a custom separate hierarchy editor is required.
