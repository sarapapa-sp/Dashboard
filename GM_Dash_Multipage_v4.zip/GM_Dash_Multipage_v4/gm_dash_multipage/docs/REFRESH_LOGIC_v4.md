# Refresh and AG Grid column-state specification — v4

## Intended behavior

**Initial visit**: `rowData=[]`. The latest COB filter is selected. The
Columns panel has these defaults:

- Row Groups: `cobdate`, `gbl`, `subbusinessline`, `activityl1` (in order).
- Inactive referential fields: `activityl5`, `ptf`, `indicator`, `source`.
- Values: every report-specific measure, with `aggFunc='sum'`.

**Before clicking REFRESH**: Users can change filters and drag fields in the
AG Grid Columns/Row Groups/Values panels. These edits do not issue any backend
query and do not update `rowData`, row-count text or the applied download
snapshot. AG Grid may rearrange the *existing* rows locally in response to
panel edits; this does not load missing data.

**On clicking REFRESH**:

```text
REFRESH.click
  |-- State(eight dropdown values)        <- no filter re-defaulting
  |-- State(grid.columnState)            <- active Row Groups & Values
  |-- reload source & normalize
  |-- apply eight filters                 <- COB defaults to latest initially
  |-- groupby(['cobdate', *other_selected_referentials])
  |-- sum(only_selected_numeric_fields)
  +-- Output(grid.rowData)                <- only selected columns returned
  +-- Output(grid-status.children)
  +-- Output(row-stats.children)
  +-- Output(applied-snapshot.data)
```

The REFRESH callback has no Output for `columnDefs`, `columnState`,
`dashGridOptions`, `defaultColDef`, or dropdown `value`. This is what prevents
previously staged groups, measures, filters and column order from reverting.

## Why a secondary column is blank until the next REFRESH

Example with Version Comparison:

1. On initial refresh, four dimensions and nine numeric values are returned.
   There is **no `activityl5` key** in each JSON row.
2. User drags Activity L5 into Row Groups. AG Grid recognizes the column
   definition, but existing rowData has no `activityl5`, so grouped labels
   appear empty/blank. The source is not reloaded at that moment.
3. User clicks REFRESH again. `columnState` now contains
   `{colId:'activityl5',rowGroup:true,rowGroupIndex:4}`. Pandas groups by five
   columns and `rowData` now contains `activityl5`.
4. If the user removes YTD_V3 from the Values list before refreshing,
   `aggFunc=None` and `ytd_v3` is omitted from the new payload.

Removing a previously selected group may cause AG Grid to roll up existing
aggregated records immediately on the client; the backend data remains
unchanged until refresh. COB is always a backend grouping key to prevent
cross-date mixing, even if COB is removed from the visible row-group panel.

## Sample data counts

With the supplied sample workbooks and the latest COB (`2026-11-19`):

| Stage | Rows |
|---|---:|
| Source (all COB dates) | 108 |
| Matching (latest COB) | 36 |
| Aggregated (COB, GBL, Sub Business Line, Activity L1) | 6 |

The data sent to the grid therefore has 6 records by default, instead of
36 detailed records containing the unselected Activity L5/Portfolio fields.
PNL totals reconcile to the original matching source for every selected measure.

## Unit-test coverage

`tests/test_v3.py` and `tests/test_v4_grid_spec.py` specifically assert:

1. There is exactly **one `Input`** driving refresh:
   `<page>-refresh.n_clicks`.
2. The eight dropdown values and `grid.columnState` are **States**, not Inputs.
3. The refresh callback has no outputs that could reset columns or filters.
4. The initial filter loader defaults to latest COB and preserves an existing
   selected COB when revisiting the page.
5. The first backend refresh sends **only** four default dimensions and page
   values, with no secondary dimensions in the payload.
6. Adding `activityl5` and removing seven of nine measures are reflected
   **only after the next refresh**.
7. The filtering selection (including selected GBL and COB) is preserved in
   the applied snapshot and used for export.
8. Aggregation reduces 36 matching rows to six; numeric sums are unchanged.
9. A failed source refresh preserves prior rows and applied snapshot.
10. The pivot/column-label drop zone is disabled while Row Groups stay active.

Run `python -m pytest -q`. These are Python tests that exercise real
Pandas aggregation and simulated Dash callback registration/execution.
They do not execute JavaScript, simulate an AG Grid Enterprise browser,
or validate client-side drag/drop. See `UI_TEST_CHECKLIST.md` for that.
