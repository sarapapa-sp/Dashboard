# Global Markets Dash AG Grid — Technical Architecture (v4)

This document explains **each directory/file**, the page/component model, the
`REFRESH` event contract, selected-column data flow, caching and production
extension points. Start with `README.md`; use `REFRESH_LOGIC_v4.md` for detailed
data-flow examples and test cases.

## 1. Design

- Frontend: Dash Pages + Dash AG Grid with AG Grid Enterprise Row Grouping and
  Columns/Values tools, plus `assets/00-style.css`.
- Backend: Pandas normalization, eight server-side filters, selected-grain
  `groupby().sum()`, a worker-level source cache and XLSX export.
- Navigation: Vertical sidebar generated from Dash's `page_registry`.
- State ownership: AG Grid owns its **live `columnState`** in the browser.
  Dropdowns own their value selections. The backend only applies them on an
  explicit REFRESH event. The latest applied selections are stored in a small
  per-page `dcc.Store`; full DataFrames are never placed in browser storage.
- Initial render: `rowData=[]`, four default Row Groups, and all report's
  Values active. Reading source to populate filter lists does **not** populate
  the grid.
- Pivoting: `pivotMode=False` and `pivotPanelShow='never'` (no Column Labels
  drop zone). Row Groups remains displayed, as does the Columns panel.

### Data flow

```text
Dash app -> selected page -> shared report layout
                          |-- eight multiselects (staged in browser)
                          |-- AG Grid Row Groups + Values (columnState)
                          |-- REFRESH button
                                   |-- read current dropdown values (State)
                                   |-- read current columnState (State)
                                   |-- get_page_data(refresh=True)
                                   |-- apply_filters()
                                   |-- aggregate_for_grid(selected group/value columns)
                                   |-- prepare_grid() -> rowData only
                                   |-- status, counts, applied snapshot
                          |-- DOWNLOAD XLSX
                                   |-- check last applied snapshot version
                                   |-- apply_filters(snapshot.filters)
                                   |-- write_excel() of underlying source
```

## 2. Complete file tree

```text
gm_dash_multipage/
├── app.py                            # Dash shell, page registry, navigation, user footer
├── report_config.py                  # Shared filters, default groups, page ReportSpecs
├── README.md                         # Setup, v4 behavior, run/test commands
├── requirements.txt                  # Dash, AG Grid, Pandas, XLSX libraries
├── .env.example                      # Environment variable examples
├── .gitignore                        # Excludes caches, venv, generated files
├── pytest.ini                        # Pytest import configuration
├── pages/
│   ├── __init__.py
│   ├── pnl.py                        # Route / + PNL ReportSpec
│   └── version_comparison.py         # Route /version-comparison + VERSIONS spec
├── core/
│   ├── __init__.py
│   ├── data_service.py               # Input read, schema normalization, cache, filters, groupby
│   ├── grid_config.py                # Initial AG Grid column defs, default groups/values
│   ├── report_page.py                # Shared layout and staged UI controls
│   ├── report_callbacks.py           # Filter initialization, REFRESH, download, request
│   ├── excel_export.py               # XLSX bytes/writer for detail exports
│   └── user_service.py               # Static (user_id, username), replace for SSO
├── assets/
│   ├── 00-style.css                  # Sidebar, multiselect chips, grid fonts/heights
│   └── dashAgGridFunctions.js        # JS numeric/accounting value formatter
├── data/
│   ├── sample_pnl.xlsx               # Synthetic PNL data, 108 rows
│   └── sample_versions.xlsx          # Synthetic V0/V1/V3 data, 108 rows
├── docs/
│   ├── TECHNICAL_ARCHITECTURE.md     # This detailed architecture guide
│   ├── REFRESH_LOGIC_v4.md           # Refresh state machine + expected test cases
│   ├── UI_TEST_CHECKLIST.md          # Manual browser acceptance checklist
│   ├── ADD_A_PAGE.md                 # Add/register a future page
│   ├── INTEGRATION.md                # Connect production files, caveats
│   ├── CHANGELOG_v2.md               # Historical notes
│   ├── CHANGELOG_v3.md               # Historical notes
│   └── CHANGELOG_v4.md               # Current changes
└── tests/
    ├── test_core.py                  # Source/filter/legacy grouping/XLSX tests
    ├── test_v3.py                    # Current refresh callback + state retention tests
    └── test_v4_grid_spec.py          # v4 default groups/values/selected grain tests
```

Generated `__pycache__`, `.pytest_cache` and `.venv` content is excluded from
release ZIPs.

## 3. Modules and functions

### `app.py` — app initialization and navigation

- `app = Dash(use_pages=True, pages_folder='pages',...)` registers routes.
- `navigation_links(pathname)` reads `dash.page_registry` and constructs the
  current active left-side menu; adding a page automatically adds a link.
- `serve_layout()` supplies the sidebar, top header, page container and
  footer. Footer gets user details from `get_current_user()`.
- `update_navigation(pathname)` updates active sidebar style on route change.
- `server` exposes the Flask server for hosting / WSGI integration.

### `report_config.py` — business configuration

- `ReportSpec` dataclass: report `key`, `name`, `path`, titles, environment file
  key, sample path, `values`, and `dimensions`.
- `PNL` and `VERSIONS`: one config per screen; each defines its own measures.
- `COMMON_DIMENSIONS`: business dimensions required by the current files.
- `DEFAULT_ROW_GROUPS`: **`('cobdate','gbl','subbusinessline','activityl1')`**.
  This tuple sets the initial AG Grid Row Group configuration.
- `FILTERS`: eight dropdown columns, four per desktop row.
- `FILTER_LABELS`: user-facing filter and group labels; `OPTIONAL_FILTERS`:
  Indicator and Source, disabled if missing from the file.
- `.required_columns` and `.value_fields` properties enforce schema and
  select page-specific measures.

### `pages/*.py` — route registration

- `pages/pnl.py` registers `/` using `PNL`.
- `pages/version_comparison.py` registers `/version-comparison` using `VERSIONS`.
- Both call `core.report_page.layout(spec)` and
  `core.report_callbacks.register_report_callbacks(spec)`; avoid duplicating
  shared UI/callback code for new reports.

### `core/report_page.py` — shared page UI

- `cid(spec,suffix)` creates page-local component IDs (e.g. `pnl-grid`).
- `filter_id(spec,field)` retains `-date` for COB and gives predictable names
  to the other dropdowns.
- `_filter_component(spec,field)` creates a searchable, session-persistent
  multi-dropdown. The dropdown component controls staged browser selections.
- `layout(spec)` builds the page title, buttons, eight selectors, request area,
  grid, row counts and status messages.
- `dcc.Store(<page>-filter-init)` triggers initial filter option loading.
- `dcc.Store(<page>-applied-snapshot)` records the **last successful REFRESH**
  filters and worker-cache sequence; no full source data is serialized.
- Initial `dag.AgGrid` uses `rowData=[]`, `build_columns(spec)`,
  `grid_options()` exactly once at page construction.

### `core/grid_config.py` — initial AG Grid specification

- `build_columns(spec)` defines all groupable referential columns. `rowGroup`
  is initially true **only** for `DEFAULT_ROW_GROUPS`; secondary dimension
  fields start with `rowGroup=False` and `hide=True`. The auto-group column
  presents grouped hierarchy labels.
- Each numeric value starts `aggFunc='sum'`, so every page-specific value is
  initially selected in the Values panel; this state can be changed by users.
- `DEFAULT_COLUMN_DEF` controls sorting, sizing, filter defaults.
- `grid_options()` enables the Row Groups panel, disables pivot mode/drop zone,
  hides count suffixes, enables Columns/Filters sidebar, pagination, row ID,
  and row/header height defaults.
- **Never rebuild `columnDefs` inside `refresh_report()`**. That was the v3
  behavior that caused AG Grid to reset user-selected row groups and measures.

### `core/data_service.py` — data pipeline

- `source_path(spec)`: resolves `DASH_PNL_FILE` or `DASH_VERSIONS_FILE`;
  defaults to `data/*.xlsx`.
- `_read_file(path)`: supports CSV, XLSX, XLSM and optional Parquet.
- `request_page_data(spec)`: integration hook for a future SQL or internal
  data loader.
- `normalize_data(df,spec)`: canonicalizes case/aliases, validates required
  fields, formats COB dates as ISO strings, normalizes strings and numeric
  measures. Optional Indicator/Source are retained when present.
- `get_page_data(spec,refresh=False)`: thread-locked, per-worker cached
  normalized DataFrame and version sequence. Initial filter read uses
  `refresh=False`; every button refresh forces reload with `refresh=True`.
- `apply_filters()`: exact multiselect filtering; OR within one selector,
  AND across selectors; empty means All.
- `aggregate_for_grid(filtered,spec,group_fields,value_fields)`: server-side
  Pandas groupby by **the applied columns**, summing only applied measures.
  `cobdate` is always retained as a backend key, even if removed from the
  visible Row Group panel. Default omitted parameters still support older
  full-grain callers for backwards compatibility.
- `filter_options(df,field)`: extracts distinct dropdown options.
- `clear_cache()`: flushes worker cache, primarily for tests.

### `core/report_callbacks.py` — callback flow

- `selection_kwargs(values)`: maps the eight filter values to data-service
  arguments (`cobdate`→`dates`, `ptf`→`portfolio`).
- `selected_grid_columns(spec,column_state)`: reads `colId`, `rowGroup`,
  `rowGroupIndex` and `aggFunc` from browser AG Grid state. Returns ordered
  selected grouping fields plus selected numeric measures. Falls back to
  defaults only when AG Grid state is missing or not initialized.
- `prepare_grid(df,spec,selections,group_fields,value_fields)`: applies filters,
  runs selected-grain groupby, adds deterministic `_row_id`, serializes only
  the selected group/value fields as JSON records.
- `make_row_statistics(...)`: constructs a text summary of source, matching,
  aggregated row count and reduction, **outside** the grid.
- `register_report_callbacks(spec)`: registers four callbacks for each page:
  1. **initialize_filters**: triggered once by `filter-init.data`; reads data
     for dropdown options, defaults latest COB, does not touch AG Grid.
  2. **refresh_report**: `Input(<page>-refresh.n_clicks)` and States for all
     eight dropdowns plus `grid.columnState`; outputs **only** grid `rowData`,
     status, row counts and applied snapshot. It never writes dropdown values,
     columnDefs, columnState or gridOptions. Errors keep prior grid/snapshot.
  3. **download_filtered**: last-applied filters + data version, then exports
     original filtered source rows as XLSX.
  4. **handle_page_request**: placeholder for later assistant integration;
     does not modify grid state.

### `core/excel_export.py` — XLSX detail download

- `write_excel(buffer,filtered,spec)` writes filtered normalized source data
  with readable labels via an in-memory Excel writer.
- `to_excel_bytes(...)` is the helper for unit testing and standalone export.
- Export intentionally does **not** reflect current client-side group/pivot
  presentation. It uses the applied filter snapshot to preserve source detail.

### `core/user_service.py` — user footer identity

- `get_current_user()` returns static `(user_id, username)` in the demo.
- Replace the function with your trusted `abc.getuser()` / identity mapping in
  production; do not use client-supplied user IDs as authoritative identities.

### `assets/`

- `00-style.css`: desktop left sidebar, responsiveness, 8 multiselects in two
  rows, inline selected chips/checkbox labels, 12px data fonts, grid spacing,
  action buttons, status box, footer.
- `dashAgGridFunctions.js`: client-side number formatter used by numeric value
  columns. Script is loaded automatically by Dash from the assets folder.

### `data/`, `tests/`, `docs/` and configuration

- `data/`: synthetic workbooks for repeatable offline validation.
- `tests/test_core.py`: original input normalization/filter/excel tests.
- `tests/test_v3.py`: includes v4-refreshed mocked callback invocation and
  assertions for single-trigger button-only backend updates.
- `tests/test_v4_grid_spec.py`: default group/value configuration, selected
  aggregation grain, numeric reconciliation and invalid selections.
- `docs/ADD_A_PAGE.md`: register a new report spec and page module.
- `docs/INTEGRATION.md`: supported files, aliases, caching, production notes.
- `docs/REFRESH_LOGIC_v4.md`: trace of how editing groups and values interacts
  with backend refresh and why a newly added dimension is blank at first.
- `docs/UI_TEST_CHECKLIST.md`: live-browser verification steps.
- `.env.example`, `requirements.txt`, `pytest.ini`, `.gitignore`: runtime
  settings, packages, tests and source-control hygiene.

## 4. Exact data contract

Required referential columns: `cobdate`, `gbl`, `subbusinessline`,
`activityl1`, `activityl5`, `ptf`; optional `indicator`, `source`.
PNL measures: `daily`, `mtd`, `ytd`, `ytdn1`. Version measures:
`daily_v0`, `mtd_v0`, `ytd_v0`, `daily_v1`, `mtd_v1`, `ytd_v1`,
`daily_v3`, `mtd_v3`, `ytd_v3`.

Aliases include `COB_Date`→`cobdate`, `Portfolio`→`ptf`, `Activity_L5`→
`activityl5`. Measure names are case-insensitive after normalization.

A group-by total is meaningful only for additive measures. Ratios and weighted
prices require a different measure definition/aggregation function.

## 5. Counts and snapshot consistency

`Source rows` = original normalized source length; `Matching rows` = length
after eight filters; `Aggregated rows` = number of backend selected-grain
rows; `Reduction` = `(Matching - Aggregated)/Matching` if Matching > 0.
These are displayed beneath action buttons, never inside AG Grid.

Source data cache is **per Python worker** and not a user-isolated snapshot.
Refreshing a page in another session can replace the shared worker snapshot,
so the export callback rejects stale applied version numbers. Multi-worker
production requires a distributed immutable cache or per-session snapshot
references to guarantee export consistency.

## 6. When something needs changing

| Task | File / function |
|---|---|
| Add new page | `report_config.py` and new `pages/<name>.py` |
| Change initial active row groups | `report_config.DEFAULT_ROW_GROUPS` |
| Change page-specific measures | `ReportSpec.values` in `report_config.py` |
| Change how selected grouping/value state is read | `core/report_callbacks.selected_grid_columns()` |
| Change groupby grain/aggregation | `core/data_service.aggregate_for_grid()` |
| Change initial AG Grid column presentation | `core/grid_config.build_columns()` |
| Hide/show pivot and row-group drop zones | `core/grid_config.grid_options()` |
| Change font/row height | `assets/00-style.css` and `core/grid_config.grid_options()` |
| Change filter labels/order | `report_config.FILTERS`, `FILTER_LABELS` and filter mapping |
| Change how REFRESH applies filters and rows | `core/report_callbacks.refresh_report()` |
| Change source reader | `core/data_service.request_page_data()` |
| Change XLSX export | `core/report_callbacks.download_filtered()`, `core/excel_export.py` |
| Integrate SSO | `core/user_service.get_current_user()` |

## 7. Verification and limitations

```bash
python -m pytest -q
python -m compileall -q app.py report_config.py core pages
python app.py
```

Automated Python tests cover selected-grain aggregation, callback dependency
wiring, persistence of staged selections, error paths and exports. **Browser
verification remains necessary** for AG Grid Enterprise drag/drop behavior,
CSS and responsive layout. The development environment for this package did
not have Dash and dash-ag-grid installed and could not install them because
network package access was unavailable.
