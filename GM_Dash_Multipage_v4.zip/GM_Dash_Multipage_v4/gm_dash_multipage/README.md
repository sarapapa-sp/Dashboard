# Global Markets Dashboard — Multipage (v4)

Two-page Dash AG Grid Enterprise reporting dashboard with a left navigation rail,
eight searchable multiselect filters, **an explicit REFRESH-only backend aggregation**,
Excel detail exports, row counts outside the grid, and a signed-in user footer.

**Important v4 correction:** AG Grid keeps the user's currently selected **Row Groups**
and **Values**. On REFRESH, Pandas groups by **only the applied Row Groups**
(COB is always a mandatory key) and sums **only the applied Values**. An
unselected secondary dimension is *not sent in rowData*. Adding it to Row Groups
later will therefore produce blank group labels until REFRESH is clicked again.
Neither the column layout nor dropdown values are reset by REFRESH.

## Start

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
pip install pytest
python -m pytest -q
python app.py
```

Open http://127.0.0.1:8050/. AG Grid row grouping and the Columns panel require
a properly configured **AG Grid Enterprise** license for corporate use.

| Screen | Route | File environment variable | Default Values |
|---|---|---|---|
| PNL Report | `/` | `DASH_PNL_FILE` | Daily, MTD, YTD, YTD N-1 |
| Version Comparison | `/version-comparison` | `DASH_VERSIONS_FILE` | Daily/MTD/YTD × V0/V1/V3 (9 measures) |

If no file variable is set, the app uses synthetic XLSX test files in `data/`.

## Initial configuration (before REFRESH)

- **Grid is empty:** `rowData=[]` — no sample or aggregated records display.
- **Default Row Groups, in order:** COB Date → GBL → Sub-Business Line → Activity L1.
- **Other Row Groups initially inactive:** Activity L5, Portfolio, Indicator, Source.
- **Default Values:** all measures defined for the page, with `sum` as aggFunc.
- **COB filter:** most recent COB selected on first page visit, using values found
  in the file. User selections persist in browser session when supported.
- **Column labels/pivot drop zone:** disabled; the Row Groups drop zone remains.
- **Height / font:** taller AG Grid, 12px data/group text, 11px headers.

## What REFRESH does

1. Reads the eight **current** multiselect filter values without changing them.
2. Reads AG Grid's `columnState`: `rowGroup` / `rowGroupIndex` and `aggFunc`.
3. Reloads the selected page's source file and applies the selected COB and
   other filters.
4. Aggregates **only** selected Row Groups + selected Values (plus mandatory
   COB key, even if its row-group chip was removed).
5. Updates **only** `rowData`, row-count text, refresh timestamp, and last-applied
   snapshot. It deliberately does not write `columnDefs`, `columnState`,
   `dashGridOptions`, or any dropdown `value`.

Immediately after editing a Row Group or Values selection, AG Grid may reorganize
its existing rows client-side. **It cannot fetch missing dimensions or measures**
until REFRESH. The just-selected column therefore appears blank with the old
payload. The next REFRESH fetches the changed aggregation grain.

`DOWNLOAD XLSX` exports **filtered underlying source rows**, based on filters
from the last successful REFRESH; it does not export the aggregated AG Grid view.

## Eight multiselect filters

| First row | Second row |
|---|---|
| COB Date | Activity L5 |
| GBL | Portfolio |
| Sub-Business Line | Indicator |
| Activity L1 | Source |

Empty selections mean All. Nonempty selections are OR within one control and
AND between controls. Indicator and Source are disabled when missing from the
input file.

## Set production input files

```bash
# Windows PowerShell
$env:DASH_PNL_FILE = 'C:\Reports\pnl.xlsx'
$env:DASH_VERSIONS_FILE = 'C:\Reports\versions.xlsx'
python app.py
```

```bash
# macOS / Linux
export DASH_PNL_FILE='/srv/reports/pnl.csv'
export DASH_VERSIONS_FILE='/srv/reports/versions.xlsx'
python app.py
```

Formats: `.xlsx`, `.xlsm`, `.csv` and `.parquet` (optional `pyarrow`).

## Documentation

- [`docs/TECHNICAL_ARCHITECTURE.md`](docs/TECHNICAL_ARCHITECTURE.md): full
  directory and file reference, callback contracts, columnState and caching.
- [`docs/REFRESH_LOGIC_v4.md`](docs/REFRESH_LOGIC_v4.md): precise refresh sequence,
  staging and examples, sample counts, and automated tests.
- [`docs/ADD_A_PAGE.md`](docs/ADD_A_PAGE.md): add another report/page.
- [`docs/INTEGRATION.md`](docs/INTEGRATION.md): source schemas and production notes.
- [`docs/UI_TEST_CHECKLIST.md`](docs/UI_TEST_CHECKLIST.md): browser acceptance tests.
- [`docs/CHANGELOG_v4.md`](docs/CHANGELOG_v4.md): v4 changes.

## Verification

```bash
python -m pytest -q
python -m compileall -q app.py core pages report_config.py
```

The 17 included tests verify the backend groupby grain, selected Values,
column-state ordering, sticky filter selections, no grid-spec outputs on refresh,
callback input contracts, XLSX export, error fallback, and source caching.
**They do not replace a live browser test.** The test environment used to
prepare v4 had no Dash/AG Grid installation and could not reach pip, so a
manual UI check using the checklist is still required.

This code builds on the preceding modular dashboard package. It is not a byte-for-byte
patch of the original `dashboard_root.zip` hosted on GitHub.
