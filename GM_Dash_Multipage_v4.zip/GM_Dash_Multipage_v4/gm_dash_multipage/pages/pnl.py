"""Page 1: original PNL dashboard with 4 value columns."""
import dash
from core.report_callbacks import register_report_callbacks
from core.report_page import layout as make_layout
from report_config import PNL

dash.register_page(__name__, path=PNL.path, name=PNL.name, order=0)
layout = make_layout(PNL)
register_report_callbacks(PNL)
