"""Page 2: separate source file; 9 Daily/MTD/YTD values across V0/V1/V3."""
import dash
from core.report_callbacks import register_report_callbacks
from core.report_page import layout as make_layout
from report_config import VERSIONS

dash.register_page(__name__, path=VERSIONS.path, name=VERSIONS.name, order=1)
layout = make_layout(VERSIONS)
register_report_callbacks(VERSIONS)
