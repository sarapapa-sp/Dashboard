# PNL Dashboard

The dashboard previously in `dash_app/` now runs from the repository root.
The application logic, filters, aggregation, Refresh Data behavior, grid configuration,
styles, sample data, and JavaScript assets are unchanged.

## Run

From this directory:

```bash
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:8050 in your browser. For a hosted tool, use the
host, port, and proxy configuration required by that tool.

Keep `sample_data.csv` and the `assets/` folder beside `app.py`.
Run the saved Python file; pasting it into a notebook does not provide `__file__`.
The CSV requires: cob_date,gbl,subsub,activityl1,daily,mtd,ytd.

The original updated_dash_app_v7.py and updated_dash_app_v7-1.py are retained.
They use the external data_service module and are separate entry points.

Moving the files preserves behavior; it does not by itself resolve an unknown
hosting error. Server logs are needed if the original error persists.
