# PNL Dashboard — updated

## Run

Keep app.py, sample_data.csv, requirements.txt and assets/ together at the root.

```bash
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:8050. Hosting environments may require their own host,
port and proxy settings. Run the saved file, rather than pasting into a notebook.

## Default grid fields

Edit DEFAULT_DIMENSIONS and DEFAULT_VALUES near the top of app.py. Only those
fields are initially active as row groups and aggregated values. All other
available dimensions remain in the Columns panel for later selection.
The default hierarchy remains cob_date, gbl, subsub, activityl1, in that order.
The new dimensions do not become active row groups automatically.
Data still loads when Refresh Data is clicked, as in the previous version.

## Filters and CSV mapping

The first four filters are:

| Label | CSV column |
| --- | --- |
| Indicator | indicator |
| Source | source |
| Activity L5 | activityl5 |
| Portfolio | ptf |

Then COB Date, GBL, Subsub and Activity L1 follow. All eight are multiselect,
are combined with AND between fields (OR within a field), and clear together.
Filter changes take effect on Refresh Data. Source data is filtered before sums.

Required existing columns: cob_date,gbl,subsub,activityl1,daily,mtd,ytd.
The four new columns are optional for backward compatibility. If missing they
are filled with nulls and their empty filter is disabled with a server warning.
Supply those columns to enable useful filtering. The bundled CSV adds explicitly
illustrative Demo values, not real business classifications. Original PNL values
are unchanged. Non-date dimension values are normalized to strings once.

## SLM / orchestrator integration

The new Analysis request section is below filters and above the grid. It includes
an input, Send button, and initially empty response paragraph. No model or API
is connected. Sending text reports this and leaves the grid untouched.

Implement orchestrate_request(text, current_view) in app.py later. It receives
current dimensions, values and filters, not the source rows. For a text-only
response return {"message": "Your answer", "view": None}.
For a grid change return, for example:

```python
return {
    "message": "Showing daily PNL by GBL and Portfolio.",
    "view": {"dimensions": ["gbl", "ptf"], "values": ["daily"]},
}
```

The callback validates allowed field names, uses the currently selected filters,
recomputes sums, and updates rowData plus columnState in the same response.
An applied view resets pivot fields so the requested grouping can be displayed
consistently. Future requests currently support grouping and measure selection;
additional plan types (filter edits, sorting, charts) require explicit handlers.
Never execute raw model-generated code. Keep source data immutable and user
view state in callback inputs, not shared module globals.

## Performance changes and next steps

- Removed printing the complete grid payload for every refresh.
- Avoided the unconditional full-source copy before filtering.
- Normalized dimension strings once at startup, rather than on each filter.
- Formatted dates after aggregation, reducing per-source-row work.
- Added a four-entry, per-process LRU cache of prepared grid results. Identical
  filter/field selections reuse results, including record conversion. It is
  entry-bounded, not byte-bounded; reduce/disable it if results consume too much RAM.
- Added orjson for Dash JSON serialization.
- Disabled debug/reloader in the standalone run command.
- Added server preparation time to the refresh status. This excludes JSON
  serialization, network transfer and browser rendering; it is not total load time.

The source remains a startup snapshot. Refresh Data re-aggregates that snapshot;
restart after CSV changes. For live reload, replace the source and filter options
and clear the cache consistently, or use a versioned dataset cache key.
The cache is not shared across server workers. For multiple workers, consider a
shared cache with data-version keys. Add user/permission scope to cache keys if
future users have different data permissions.

For millions of rows, measure ingestion, aggregation, serialized payload size and
browser render time separately. Client-side pagination still transfers all
aggregated rows; it does not provide server-side paging. A small sample cannot
predict performance on your real data. If aggregation remains slow, evaluate a
columnar query engine and partitioned data storage. If transfer is the bottleneck,
use server-side filtering/grouping/paging with the grid row model appropriate to
your license. Preserve aggregation semantics across pages.

Official references:
- https://dash.plotly.com/advanced-callbacks (memoization)
- https://dash.plotly.com/dash-2-0-migration (orjson support)
- https://dash.plotly.com/devtools (reloader and performance measurements)

The older updated_dash_app_v7*.py files remain separate, unchanged entry points
requiring your data_service module. Use app.py for this updated dashboard.
