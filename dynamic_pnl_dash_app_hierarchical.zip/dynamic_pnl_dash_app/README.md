# GM PNL Reporting - Dash + AG Grid

## Files
- `app.py`: Dash application, `load_data()` and callbacks.
- `sample_data.csv`: sample source data.
- `requirements.txt`: Python dependencies.
- `assets/style.css`: dashboard and grid styling.
- `assets/dashAgGridComponentFunctions.js`: expandable/collapsible tree cell renderer.

## Run
```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:8050

## Referential hierarchy
Select one or more referential columns. Their selection order defines the hierarchy.
All referential fields appear in a single `REFERENTIAL` column. Use the arrow buttons
to expand and collapse individual branches.

The numeric columns (`daily`, `mtd`, `ytd`) are summed at every hierarchy level.
The `load_data()` function always starts from the original source DataFrame.

## Filtering
The custom Filters panel filters the original source records before aggregation.
The grid also retains its own floating column filters and filter menus.

The custom Filters panel is implemented with Dash controls and does not require
AG Grid Enterprise. AG Grid's built-in Filters Tool Panel sidebar is an Enterprise
feature and is not required by this application.
